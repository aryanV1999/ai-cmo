"use client";

import { useEffect, useState, useCallback } from "react";
import { useParams } from "next/navigation";
import { ProgressDisplay } from "@/components/progress-display";
import { EmailCaptureModal } from "@/components/email-capture-modal";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  ArrowLeft,
  Download,
  Share2,
  ExternalLink,
  AlertTriangle,
  AlertCircle,
  Info,
  CheckCircle,
  Zap,
  Lock,
} from "lucide-react";
import Link from "next/link";
import { cn, getSeverityColor } from "@/lib/utils";

interface AuditData {
  id: string;
  siteUrl: string;
  domain: string;
  status: string;
  progress: number;
  currentStep: string;
  grade?: string;
  gradeScore?: number;
  isUnlocked?: boolean;
  requiresEmail?: boolean;
  teaser?: {
    grade?: string;
    gradeScore?: number;
    criticalIssuesCount: number;
    topIssues: Array<{ title: string; severity: string; category: string }>;
    summary: string;
    summarySnippet?: string;
  };
  fullReport?: {
    brandOverview?: Record<string, unknown>;
    technicalSeo: Record<string, unknown>;
    onPageSeo: Record<string, unknown>;
    pageSpeed: Record<string, unknown>;
    competitors?: Record<string, unknown> | null;
    channels?: Record<string, unknown> | null;
    aiSummary: Record<string, unknown>;
    actions?: Array<{
      id: string;
      title: string;
      whyNow?: string;
      expectedResult?: string;
      effortMinutes?: number;
      steps?: string[];
    }>;
    findings: Array<{
      id: string;
      category: string;
      type: string;
      severity: string;
      title: string;
      description: string;
      impact: string;
      howToFix: string;
      affectedCount: number;
      serviceId?: string;
      serviceCta?: string;
    }>;
    pdfUrl?: string;
  };
}

export default function AuditPage() {
  const params = useParams();
  const auditId = params.id as string;

  const [audit, setAudit] = useState<AuditData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showEmailModal, setShowEmailModal] = useState(false);

  const fetchAudit = useCallback(async () => {
    try {
      const response = await fetch(`/api/audits/${auditId}`);
      if (!response.ok) {
        throw new Error("Failed to fetch audit");
      }
      const data = await response.json();
      setAudit(data);

      // Keep polling if audit is still in progress
      if (data.status !== "COMPLETE" && data.status !== "FAILED") {
        setTimeout(fetchAudit, 2000);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  }, [auditId]);

  useEffect(() => {
    fetchAudit();
  }, [fetchAudit]);

  const handleUnlock = async (email: string) => {
    const response = await fetch(`/api/audits/${auditId}/unlock`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });

    if (!response.ok) {
      const data = await response.json();
      throw new Error(data.error || "Failed to unlock report");
    }

    setShowEmailModal(false);
    fetchAudit();
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto" />
          <p className="mt-4 text-muted-foreground">Loading audit...</p>
        </div>
      </div>
    );
  }

  if (error || !audit) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <AlertTriangle className="w-12 h-12 text-red-500 mx-auto" />
          <h2 className="mt-4 text-xl font-semibold">Audit Not Found</h2>
          <p className="mt-2 text-muted-foreground">{error}</p>
          <Link href="/">
            <Button className="mt-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  // Show progress screen while audit is running
  if (audit.status !== "COMPLETE" && audit.status !== "FAILED") {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
        <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
          <div className="container mx-auto px-4 py-4">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold text-primary">Motion Labs AI</span>
            </Link>
          </div>
        </header>

        <main className="container mx-auto px-4 py-20">
          <div className="max-w-2xl mx-auto text-center">
            <h1 className="text-3xl font-bold text-primary mb-4">
              Analyzing Your Website
            </h1>
            <p className="text-muted-foreground mb-12">
              {audit.siteUrl}
            </p>

            <ProgressDisplay
              progress={audit.progress}
              currentStep={audit.currentStep}
              status={audit.status}
            />
          </div>
        </main>
      </div>
    );
  }

  // Show failed state
  if (audit.status === "FAILED") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <AlertTriangle className="w-12 h-12 text-red-500 mx-auto" />
          <h2 className="mt-4 text-xl font-semibold">Audit Failed</h2>
          <p className="mt-2 text-muted-foreground">
            We encountered an error while analyzing your website.
          </p>
          <Link href="/">
            <Button className="mt-4">Try Another Website</Button>
          </Link>
        </div>
      </div>
    );
  }

  const fullReport = audit.fullReport;
  const aiSummary = fullReport?.aiSummary;
  const immediateActions =
    (aiSummary?.immediateActions as Array<Record<string, unknown>> | undefined) || [];
  const hasImmediateActions = immediateActions.length > 0;
  const hasMarketingStrategy = hasUsefulMarketingStrategy(aiSummary);

  // Show results
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold text-primary">Motion Labs AI</span>
          </Link>

          <div className="flex items-center space-x-3">
            <Button variant="outline" size="sm">
              <Share2 className="w-4 h-4 mr-2" />
              Share
            </Button>
            {audit.isUnlocked && (
              <Button variant="accent" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Download PDF
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-12 bg-white border-b">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <div className="mb-6 flex justify-center">
              <div className="rounded-xl border bg-slate-50 px-8 py-5 shadow-sm">
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Overall score
                </p>
                <p className="mt-1 text-5xl font-bold text-primary">
                  {audit.gradeScore ?? "?"}
                  <span className="text-xl font-semibold text-muted-foreground">/100</span>
                </p>
              </div>
            </div>

            <h1 className="text-2xl md:text-3xl font-bold text-primary mb-2">
              Audit Results for
            </h1>
            <a
              href={audit.siteUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-lg text-accent hover:underline inline-flex items-center"
            >
              {audit.domain}
              <ExternalLink className="w-4 h-4 ml-1" />
            </a>

            {audit.teaser && (
              <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto">
                {audit.teaser.summary}
              </p>
            )}
          </div>
        </div>
      </section>

      {/* Top Issues Teaser */}
      {audit.teaser && audit.teaser.topIssues.length > 0 && (
        <section className="py-8 bg-red-50 border-b border-red-100">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-lg font-semibold text-red-800 mb-4 flex items-center">
                <AlertTriangle className="w-5 h-5 mr-2" />
                {audit.teaser.criticalIssuesCount} Critical Issues Found
              </h2>
              <div className="space-y-3">
                {audit.teaser.topIssues.map((issue, i) => (
                  <div
                    key={i}
                    className="flex items-start gap-3 bg-white p-4 rounded-lg border border-red-200"
                  >
                    <AlertTriangle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-red-800">{issue.title}</p>
                      <p className="text-sm text-red-600 capitalize">
                        {issue.category.replace("_", " ")}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Email Gate or Full Report */}
      {!audit.isUnlocked ? (
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-2xl mx-auto text-center">
              <div className="relative">
                {/* Blurred preview */}
                <div className="blur-gate p-8 bg-slate-100 rounded-xl">
                  <div className="h-64 bg-slate-200 rounded-lg mb-4" />
                  <div className="h-32 bg-slate-200 rounded-lg mb-4" />
                  <div className="h-48 bg-slate-200 rounded-lg" />
                </div>

                {/* Unlock overlay */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="bg-white p-8 rounded-xl shadow-xl border max-w-md mx-4">
                    <Lock className="w-12 h-12 text-accent mx-auto mb-4" />
                    <h3 className="text-xl font-bold mb-2">
                      Unlock Your Full Report
                    </h3>
                    <p className="text-muted-foreground mb-6">
                      Enter your email to access the complete audit with
                      detailed findings, competitor analysis, and personalized
                      recommendations.
                    </p>
                    <Button
                      variant="accent"
                      size="lg"
                      className="w-full"
                      onClick={() => setShowEmailModal(true)}
                    >
                      Unlock My Report
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      ) : (
        // Full Report
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              {fullReport?.brandOverview && (
                <div className="bg-white rounded-xl border shadow-sm p-8 mb-8">
                  <h2 className="text-2xl font-bold text-primary mb-4">
                    Brand Overview
                  </h2>
                  <BrandOverview overview={fullReport.brandOverview} />
                </div>
              )}

              {/* AI Summary */}
              {Boolean(aiSummary) && (
                <div className="bg-white rounded-xl border shadow-sm p-8 mb-8">
                  <h2 className="text-2xl font-bold text-primary mb-4">
                    CMO Summary
                  </h2>
                  <CMOSummary aiSummary={aiSummary!} />
                </div>
              )}

              {hasImmediateActions && (
                <div className="bg-white rounded-xl border shadow-sm p-8 mb-8">
                  <h2 className="text-2xl font-bold text-primary mb-4">
                    Immediate Growth Actions
                  </h2>
                  <div className="grid gap-4">
                    {immediateActions
                      .slice(0, 5)
                      .map((action, i) => (
                        <ActionCard key={String(action.id || i)} action={action} />
                      ))}
                  </div>
                </div>
              )}

              {fullReport?.competitors && (
                <div className="bg-white rounded-xl border shadow-sm p-8 mb-8">
                  <h2 className="text-2xl font-bold text-primary mb-4">
                    Competitor Analysis
                  </h2>
                  <CompetitorAnalysis competitors={fullReport.competitors} aiSummary={aiSummary} />
                </div>
              )}

              {fullReport?.channels && (
                <div className="bg-white rounded-xl border shadow-sm p-8 mb-8">
                  <h2 className="text-2xl font-bold text-primary mb-4">
                    Social Media Analysis
                  </h2>
                  <SocialChannelAnalysis channels={fullReport.channels} aiSummary={aiSummary} />
                </div>
              )}

              {hasMarketingStrategy && (
                <div className="bg-white rounded-xl border shadow-sm p-8 mb-8">
                  <h2 className="text-2xl font-bold text-primary mb-4">
                    Marketing Channel Strategy
                  </h2>
                  <MarketingStrategy aiSummary={aiSummary!} />
                </div>
              )}

              {/* Findings by Category */}
              {audit.fullReport?.findings && (
                <div className="space-y-6">
                  <h2 className="text-xl font-bold text-primary">
                    All Findings
                  </h2>

                  <Accordion type="multiple" className="space-y-4">
                    {/* Group findings by category */}
                    {["technical", "onpage", "speed", "competitor", "marketing"].map(
                      (category) => {
                        const categoryFindings = audit.fullReport!.findings.filter(
                          (f) => f.category === category
                        );
                        if (categoryFindings.length === 0) return null;

                        const categoryNames: Record<string, string> = {
                          technical: "Technical SEO",
                          onpage: "On-Page SEO",
                          speed: "Page Speed",
                          competitor: "Competitor Analysis",
                          marketing: "Marketing Channels",
                        };

                        return (
                          <AccordionItem
                            key={category}
                            value={category}
                            className="bg-white rounded-xl border shadow-sm"
                          >
                            <AccordionTrigger className="px-6 py-4">
                              <div className="flex items-center justify-between w-full pr-4">
                                <span className="font-semibold">
                                  {categoryNames[category]}
                                </span>
                                <span className="text-sm text-muted-foreground">
                                  {categoryFindings.length} issues
                                </span>
                              </div>
                            </AccordionTrigger>
                            <AccordionContent className="px-6 pb-6">
                              <div className="space-y-4">
                                {categoryFindings.map((finding) => (
                                  <FindingCard
                                    key={finding.id}
                                    finding={finding}
                                  />
                                ))}
                              </div>
                            </AccordionContent>
                          </AccordionItem>
                        );
                      }
                    )}
                  </Accordion>
                </div>
              )}

              {/* CTA Section */}
              <div className="mt-12 bg-primary rounded-xl p-8 text-white text-center">
                <h2 className="text-2xl font-bold mb-4">
                  Ready to Fix These Issues?
                </h2>
                <p className="text-primary-100 mb-6 max-w-2xl mx-auto">
                  Our team of SEO experts can help you implement these fixes
                  and grow your organic traffic.
                </p>
                <Button variant="accent" size="lg">
                  Talk to Motion Labs
                </Button>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Email Modal */}
      <EmailCaptureModal
        isOpen={showEmailModal}
        onClose={() => setShowEmailModal(false)}
        onSubmit={handleUnlock}
        auditId={auditId}
        score={audit.gradeScore ?? 0}
      />
    </div>
  );
}

function CMOSummary({ aiSummary }: { aiSummary: Record<string, unknown> }) {
  const executiveSummary = aiSummary.executiveSummary as Record<string, unknown> | undefined;
  const categoryScores = aiSummary.categoryScores as Record<string, number> | undefined;

  if (!executiveSummary) {
    return (
      <p className="text-lg leading-relaxed">
        {(aiSummary.brutalVerdict as string) || "Your report is ready."}
      </p>
    );
  }

  return (
    <div className="space-y-5">
      <p className="text-xl font-semibold leading-snug">
        {String(executiveSummary.headline || "")}
      </p>
      <p className="text-muted-foreground leading-relaxed">
        {String(executiveSummary.currentState || "")}
      </p>
      <div className="grid gap-4 md:grid-cols-3">
        <SummaryMetric label="Top opportunity" value={String(executiveSummary.topOpportunity || "Not available")} />
        <SummaryMetric label="Expected impact" value={String(executiveSummary.expectedImpact || "Not available")} />
        <SummaryMetric label="Time to value" value={String(executiveSummary.timeToValue || "Not available")} />
      </div>
      {categoryScores && (
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
          {Object.entries(categoryScores).map(([key, value]) => (
            <div key={key} className="rounded-lg border bg-slate-50 p-3">
              <p className="text-xs uppercase text-muted-foreground">
                {key.replace(/([A-Z])/g, " $1")}
              </p>
              <p className="mt-1 text-2xl font-bold text-primary">{value}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function SummaryMetric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border bg-slate-50 p-4">
      <p className="text-xs font-semibold uppercase text-muted-foreground">{label}</p>
      <p className="mt-2 text-sm leading-relaxed">{value}</p>
    </div>
  );
}

function BrandOverview({ overview }: { overview: Record<string, unknown> }) {
  const sampledPages = (overview.sampledPages as Array<Record<string, unknown>> | undefined) || [];
  const h1Tags = (overview.h1Tags as string[] | undefined) || [];
  const detectedSchema = (overview.detectedSchema as string[] | undefined) || [];

  return (
    <div className="space-y-5">
      <div>
        <p className="text-xl font-semibold text-primary">
          {String(overview.title || overview.domain || "Brand")}
        </p>
        <p className="mt-2 text-muted-foreground leading-relaxed">
          {String(overview.metaDescription || "No homepage meta description was detected, so the brand summary is limited to crawl evidence.")}
        </p>
      </div>
      <div className="grid gap-3 md:grid-cols-3">
        <SummaryMetric label="Domain" value={String(overview.domain || "Not available")} />
        <SummaryMetric label="Pages crawled" value={String(overview.pagesCrawled || 0)} />
        <SummaryMetric label="Pages discovered" value={String(overview.pagesDiscovered || 0)} />
      </div>
      {h1Tags.length > 0 && (
        <div>
          <p className="font-semibold text-primary">Primary positioning signals</p>
          <ul className="mt-2 list-disc space-y-1 pl-5 text-sm">
            {h1Tags.slice(0, 5).map((heading, i) => <li key={i}>{heading}</li>)}
          </ul>
        </div>
      )}
      {detectedSchema.length > 0 && (
        <p className="text-sm text-muted-foreground">
          Schema detected: {detectedSchema.join(", ")}
        </p>
      )}
      {sampledPages.length > 0 && (
        <div>
          <p className="font-semibold text-primary">Pages used for brand context</p>
          <div className="mt-2 grid gap-2">
            {sampledPages.slice(0, 5).map((page, i) => (
              <div key={i} className="rounded-lg border bg-slate-50 p-3 text-sm">
                <p className="font-medium">{String(page.title || page.url || "Untitled page")}</p>
                <p className="mt-1 break-all text-muted-foreground">{String(page.url || "")}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function ActionCard({ action }: { action: Record<string, unknown> }) {
  const steps = (action.implementationSteps as string[] | undefined) || [];
  const affectedPages = (action.affectedPages as string[] | undefined) || [];

  return (
    <div className="rounded-lg border p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="font-semibold text-primary">{String(action.title || "Action")}</p>
          <p className="mt-1 text-sm text-muted-foreground">
            {String(action.description || "")}
          </p>
        </div>
        <span className="rounded-md bg-accent/10 px-2 py-1 text-xs font-semibold text-accent">
          {String(action.priority || "HIGH")}
        </span>
      </div>
      {affectedPages.length > 0 && (
        <p className="mt-3 text-xs text-muted-foreground">
          Pages: {affectedPages.slice(0, 3).join(", ")}
        </p>
      )}
      {steps.length > 0 && (
        <ol className="mt-3 list-decimal space-y-1 pl-5 text-sm">
          {steps.slice(0, 4).map((step, i) => (
            <li key={i}>{step}</li>
          ))}
        </ol>
      )}
      <p className="mt-3 text-sm">
        <strong>Outcome:</strong> {String(action.expectedOutcome || action.impact || "Improved marketing performance")}
      </p>
    </div>
  );
}

function CompetitorAnalysis({
  competitors,
  aiSummary,
}: {
  competitors: Record<string, unknown>;
  aiSummary?: Record<string, unknown>;
}) {
  const competitorInsights = aiSummary?.competitorInsights as Record<string, unknown> | undefined;
  const competitorList = (competitors.competitors as Array<Record<string, unknown>> | undefined) || [];
  const aiIdentifiedCompetitors = (competitorInsights?.identifiedCompetitors as string[] | undefined) || [];
  const comparisons = (competitors.comparisons as Array<Record<string, unknown>> | undefined) || [];
  const summary = competitors.summary as Record<string, unknown> | undefined;
  const notes = (competitors.notes as string[] | undefined) || [];
  const dataQuality = String(competitors.dataQuality || "unavailable");
  const competitorStrengths = (competitorInsights?.competitorStrengths as string[] | undefined) || [];
  const differentiation =
    (competitorInsights?.differentiationOpportunities as string[] | undefined) || [];
  const primaryGaps =
    (competitorInsights?.gapsToExploit as string[] | undefined) ||
    (summary?.primaryGaps as string[] | undefined) ||
    [];
  const quickWins =
    (competitorInsights?.differentiationOpportunities as string[] | undefined) ||
    (summary?.quickWins as string[] | undefined) ||
    [];
  const displayedCompetitors = aiIdentifiedCompetitors.length > 0
    ? aiIdentifiedCompetitors
    : competitorList.map((competitor) => String(competitor.domain || "")).filter(Boolean);

  return (
    <div className="space-y-5">
      <div className="rounded-lg border bg-slate-50 p-4">
        <p className="text-xs font-semibold uppercase text-muted-foreground">
          Competitors found ({dataQuality.replace(/-/g, " ")})
        </p>
        <p className="mt-2 text-lg font-semibold text-primary">
          {displayedCompetitors.length > 0
            ? displayedCompetitors.join(", ")
            : "No reliable competitor domains found yet"}
        </p>
      </div>
      {notes.length > 0 && (
        <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
          {notes.slice(0, 2).map((note, i) => <p key={i}>{note}</p>)}
        </div>
      )}
      {competitorList.length > 0 && (
        <div className="grid gap-3 md:grid-cols-2">
          {competitorList.slice(0, 4).map((competitor, i) => (
            <div key={i} className="rounded-lg border bg-slate-50 p-4">
              <p className="font-semibold text-primary">{String(competitor.domain || "Competitor")}</p>
              {competitor.metricsAvailable ? (
                <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
                  <p>DA: <strong>{String(competitor.domainAuthority ?? "N/A")}</strong></p>
                  <p>Keywords: <strong>{String(competitor.organicKeywords ?? "N/A")}</strong></p>
                  <p>Ref domains: <strong>{String(competitor.referringDomains ?? "N/A")}</strong></p>
                  <p>Content/mo: <strong>{String(competitor.contentVelocity ?? "N/A")}</strong></p>
                </div>
              ) : (
                <p className="mt-3 text-sm text-muted-foreground">
                  Discovered through web research. SEO metrics unavailable until a data provider is connected.
                </p>
              )}
            </div>
          ))}
        </div>
      )}
      <TwoColumnList
        leftTitle="Competitor strengths"
        leftItems={competitorStrengths}
        rightTitle="Your positioning opportunities"
        rightItems={[...differentiation, ...quickWins]}
        leftFallback="Competitor strengths need deeper market data or AI report context."
        rightFallback="No clear positioning opportunities were available from the current dataset."
      />
      <TwoColumnList
        leftTitle="Disadvantages vs competitors"
        leftItems={primaryGaps}
        rightTitle="Advantages to exploit"
        rightItems={quickWins}
        leftFallback="No clear disadvantages were available from the competitor dataset."
        rightFallback="No clear advantages were available from the competitor dataset."
      />
      {comparisons.length > 0 && (
        <div>
          <p className="font-semibold text-primary">Research notes</p>
          <div className="mt-2 space-y-2">
            {comparisons.slice(0, 4).map((comparison, i) => (
              <div key={i} className="rounded-lg border p-3 text-sm">
                <p className="font-medium">{String(comparison.metric || "Insight")}</p>
                <p className="mt-1 text-muted-foreground">{String(comparison.gap || comparison.recommendation || "")}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function SocialChannelAnalysis({
  channels,
  aiSummary,
}: {
  channels: Record<string, unknown>;
  aiSummary?: Record<string, unknown>;
}) {
  const channelList = (channels.channels as Array<Record<string, unknown>> | undefined) || [];
  const socialChannel = channelList.find((channel) =>
    String(channel.channel || "").toLowerCase().includes("social")
  );
  const socialStrategy = aiSummary?.socialStrategy as Record<string, unknown> | undefined;
  const platformRecommendations =
    (socialStrategy?.platformRecommendations as Array<Record<string, unknown>> | undefined) || [];
  const evidence = (socialChannel?.evidence as Array<Record<string, unknown>> | undefined) || [];
  const recommendations = (socialChannel?.recommendations as string[] | undefined) || [];
  const socialMetrics = (socialChannel?.metrics as Record<string, unknown> | undefined) || {};
  const socialBreakdown = (socialMetrics.breakdown as Record<string, unknown> | undefined) || {};
  const themeDistribution = (socialMetrics.theme_distribution as Record<string, unknown> | undefined) || {};
  const brandAlignment = (socialMetrics.brand_alignment as Record<string, unknown> | undefined) || {};
  const socialScore = getSocialMediaScore(socialChannel);
  const strengths = buildSocialStrengths(socialChannel, evidence, platformRecommendations, socialStrategy);
  const improvements = buildSocialImprovements(socialChannel, recommendations, platformRecommendations, socialStrategy);

  return (
    <div className="space-y-5">
      <div className="grid gap-3 md:grid-cols-3">
        <SummaryMetric label="Social media score" value={`${socialScore}/100`} />
        <SummaryMetric label="Status" value={String(socialChannel?.status || "Not detected")} />
        <SummaryMetric label="Platforms found" value={String(socialMetrics.platformCount || evidence.length || 0)} />
        <SummaryMetric label="Profiles with API data" value={String(socialMetrics.profilesWithMetrics || 0)} />
        <SummaryMetric label="Total followers" value={formatMetricNumber(socialMetrics.totalFollowers)} />
        <SummaryMetric label="Data sources" value={String(socialMetrics.dataSources || "profile-discovery-only")} />
      </div>
      <p className="text-muted-foreground leading-relaxed">
        {String(socialChannel?.details || "No public social media profiles were detected from the website or web research.")}
      </p>
      {Object.keys(socialBreakdown).length > 0 && (
        <div>
          <p className="font-semibold text-primary">Computed score breakdown</p>
          <div className="mt-2 grid gap-2 md:grid-cols-5">
            {Object.entries(socialBreakdown).map(([key, value]) => (
              <div key={key} className="rounded-lg border bg-slate-50 p-3">
                <p className="text-xs uppercase text-muted-foreground">{key.replace(/_/g, " ")}</p>
                <p className="mt-1 text-xl font-bold text-primary">{String(value)}/100</p>
              </div>
            ))}
          </div>
        </div>
      )}
      {Object.keys(themeDistribution).length > 0 && (
        <div>
          <p className="font-semibold text-primary">Recent content theme mix</p>
          <div className="mt-2 grid gap-2 md:grid-cols-3">
            {Object.entries(themeDistribution).slice(0, 6).map(([theme, percent]) => (
              <div key={theme} className="rounded-lg border bg-slate-50 p-3 text-sm">
                <p className="font-medium capitalize">{theme.replace(/_/g, " ")}</p>
                <p className="mt-1 text-muted-foreground">{String(percent)}% of sampled posts</p>
              </div>
            ))}
          </div>
        </div>
      )}
      {Boolean(brandAlignment.status) && (
        <div className="rounded-lg border bg-slate-50 p-4 text-sm">
          <p className="font-semibold text-primary">Brand consistency</p>
          <p className="mt-1 capitalize text-muted-foreground">
            {String(brandAlignment.status).replace(/-/g, " ")} - score {String(brandAlignment.score ?? "N/A")}/100
          </p>
          {Array.isArray(brandAlignment.issues) && brandAlignment.issues.length > 0 && (
            <ul className="mt-2 list-disc space-y-1 pl-5">
              {(brandAlignment.issues as string[]).slice(0, 3).map((issue, i) => <li key={i}>{issue}</li>)}
            </ul>
          )}
        </div>
      )}
      {evidence.length > 0 && (
        <div>
          <p className="font-semibold text-primary">Detected social platforms</p>
          <div className="mt-2 grid gap-2 md:grid-cols-2">
            {evidence.map((item, i) => (
              <a
                key={i}
                href={String(item.source || "#")}
                target="_blank"
                rel="noopener noreferrer"
                className="rounded-lg border bg-slate-50 p-3 text-sm hover:border-accent"
              >
                <p className="font-medium">{String(item.value || "Social profile")}</p>
                <p className="mt-1 break-all text-muted-foreground">{String(item.source || "")}</p>
              </a>
            ))}
          </div>
        </div>
      )}
      <TwoColumnList
        leftTitle="Social strengths"
        leftItems={strengths}
        rightTitle="Social improvements"
        rightItems={improvements}
        leftFallback="No clear social strengths detected yet."
        rightFallback="No specific social improvements detected yet."
      />
    </div>
  );
}

function getSocialMediaScore(socialChannel?: Record<string, unknown>): number {
  if (!socialChannel) return 0;

  const status = String(socialChannel.status || "missing");
  const metrics = (socialChannel.metrics as Record<string, unknown> | undefined) || {};
  const storedScore = Number(metrics.social_strength ?? metrics.socialScore);
  const platformCount = Number(metrics.platformCount || 0);
  const profilesWithMetrics = Number(metrics.profilesWithMetrics || 0);
  const totalFollowers = Number(metrics.totalFollowers || 0);
  const totalRecentPosts = Number(metrics.totalRecentPosts || 0);
  const avgEngagementRate = Number(metrics.avgEngagementRate || 0);

  if (status === "missing") return 0;
  if (Number.isFinite(storedScore) && storedScore > 0) return storedScore;

  const engagement = avgEngagementRate > 1 ? avgEngagementRate / 100 : avgEngagementRate;
  const presenceScore = Math.min(30, platformCount * 6);
  const dataQualityScore = Math.min(20, profilesWithMetrics * 10);
  const audienceScore = totalFollowers > 0 ? Math.min(20, Math.log10(totalFollowers + 1) * 4) : 0;
  const activityScore = Math.min(15, totalRecentPosts * 1.5);
  const engagementScore = engagement > 0 ? Math.min(15, engagement * 250) : 0;

  return Math.min(100, Math.round(presenceScore + dataQualityScore + audienceScore + activityScore + engagementScore));
}

function formatMetricNumber(value: unknown): string {
  const number = Number(value || 0);
  if (!Number.isFinite(number) || number <= 0) return "Not available";
  return Intl.NumberFormat("en", { notation: "compact", maximumFractionDigits: 1 }).format(number);
}

function buildSocialStrengths(
  socialChannel: Record<string, unknown> | undefined,
  evidence: Array<Record<string, unknown>>,
  platformRecommendations: Array<Record<string, unknown>>,
  socialStrategy?: Record<string, unknown>
): string[] {
  if (!socialChannel) return [];

  const metrics = (socialChannel.metrics as Record<string, unknown> | undefined) || {};
  const profileBreakdown = (metrics.profileBreakdown as Array<Record<string, unknown>> | undefined) || [];
  const evidenceSummary = (metrics.evidence_summary as string[] | undefined) || [];
  const strengths: string[] = [];

  strengths.push(
    ...((socialStrategy?.strengths as string[] | undefined) || []).filter((item) => !isGenericSocialText(item)),
    ...evidenceSummary
  );

  for (const profile of profileBreakdown) {
    const platform = String(profile.platform || "Social profile");
    const followers = formatMetricNumber(profile.followers);
    const source = String(profile.dataSource || profile.data_source || "profile-discovery-only");
    const url = String(profile.url || "");
    if (followers !== "Not available") {
      strengths.push(`${platform}: ${followers} followers found from ${source}${url ? ` (${url})` : ""}.`);
    } else if (url) {
      strengths.push(`${platform}: official profile detected at ${url}; audience metrics are not available yet.`);
    }
  }

  for (const platform of platformRecommendations) {
    const platformName = String(platform.platform || "Platform");
    const currentState = String(platform.currentState || "").trim();
    if (currentState && !isGenericSocialText(currentState)) {
      strengths.push(`${platformName}: ${currentState}`);
    }
  }

  const assessment = String(socialStrategy?.overallAssessment || "").trim();
  if (assessment && !isGenericSocialText(assessment)) {
    strengths.push(assessment);
  }

  if (strengths.length === 0 && evidence.length > 0) {
    strengths.push(...evidence.slice(0, 4).map((item) => String(item.value || item.source || "Social profile detected.")));
  }

  return Array.from(new Set(strengths)).slice(0, 8);
}

function buildSocialImprovements(
  socialChannel: Record<string, unknown> | undefined,
  recommendations: string[],
  platformRecommendations: Array<Record<string, unknown>>,
  socialStrategy?: Record<string, unknown>
): string[] {
  const improvements: string[] = [];

  improvements.push(
    ...((socialStrategy?.weaknesses as string[] | undefined) || []).filter((item) => !isGenericSocialText(item)),
    ...((socialStrategy?.growthOpportunities as string[] | undefined) || []).filter((item) => !isGenericSocialText(item)),
    ...((socialStrategy?.ninetyDayActionPlan as string[] | undefined) || []).filter((item) => !isGenericSocialText(item))
  );

  for (const platform of platformRecommendations) {
    const platformName = String(platform.platform || "Platform");
    const recs = (platform.recommendations as string[] | undefined) || [];
    const contentTypes = (platform.contentTypes as string[] | undefined) || [];
    if (recs.length > 0) {
      improvements.push(`${platformName}: ${recs.slice(0, 3).join("; ")}`);
    }
    if (contentTypes.length > 0) {
      improvements.push(`${platformName}: test ${contentTypes.slice(0, 3).join(", ")} content formats.`);
    }
  }

  improvements.push(
    ...((socialStrategy?.contentCalendarIdeas as string[] | undefined) || []).slice(0, 4),
    ...((socialStrategy?.integrationOpportunities as string[] | undefined) || []).slice(0, 4)
  );

  improvements.push(...recommendations.filter((item) => !isGenericSocialText(item)));

  if (!socialChannel || String(socialChannel.status || "") === "missing") {
    improvements.push("Add official social profile links to the site header or footer so users and crawlers can verify the brand ecosystem.");
  }
  if (Number((socialChannel?.metrics as Record<string, unknown> | undefined)?.profilesWithMetrics || 0) === 0) {
    improvements.push("Connect SocialData for X/Twitter and Apify for Instagram, TikTok, YouTube, and other public profile metrics.");
  }

  return Array.from(new Set(improvements)).slice(0, 8);
}

function isGenericSocialText(value: string): boolean {
  const normalized = value.toLowerCase().trim();
  return [
    "needs review",
    "social presence analysis pending",
    "share industry insights",
    "engage with community",
    "weekly tips",
    "monthly deep dives",
    "repurpose blog content to social",
  ].some((generic) => normalized === generic || normalized.includes(generic));
}

function TwoColumnList({
  leftTitle,
  leftItems,
  rightTitle,
  rightItems,
  leftFallback = "No clear gaps were available from the current dataset.",
  rightFallback = "No quick wins were available from the current dataset.",
}: {
  leftTitle: string;
  leftItems: string[];
  rightTitle: string;
  rightItems: string[];
  leftFallback?: string;
  rightFallback?: string;
}) {
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <ListPanel title={leftTitle} items={leftItems} fallback={leftFallback} />
      <ListPanel title={rightTitle} items={rightItems} fallback={rightFallback} />
    </div>
  );
}

function ListPanel({ title, items, fallback }: { title: string; items: string[]; fallback: string }) {
  return (
    <div className="rounded-lg border bg-slate-50 p-4">
      <p className="font-semibold text-primary">{title}</p>
      {items.length > 0 ? (
        <ul className="mt-2 list-disc space-y-1 pl-5 text-sm">
          {items.slice(0, 6).map((item, i) => <li key={i}>{item}</li>)}
        </ul>
      ) : (
        <p className="mt-2 text-sm text-muted-foreground">{fallback}</p>
      )}
    </div>
  );
}

function hasUsefulMarketingStrategy(aiSummary?: Record<string, unknown>): boolean {
  const socialStrategy = aiSummary?.socialStrategy as Record<string, unknown> | undefined;
  if (!socialStrategy) return false;

  const assessment = String(socialStrategy.overallAssessment || "").trim().toLowerCase();
  const platformRecommendations =
    (socialStrategy.platformRecommendations as Array<Record<string, unknown>> | undefined) || [];
  const contentCalendarIdeas = (socialStrategy.contentCalendarIdeas as string[] | undefined) || [];
  const integrationOpportunities = (socialStrategy.integrationOpportunities as string[] | undefined) || [];

  return (
    platformRecommendations.length > 0 ||
    contentCalendarIdeas.length > 0 ||
    integrationOpportunities.length > 0 ||
    (assessment.length > 0 && assessment !== "needs review")
  );
}

function MarketingStrategy({ aiSummary }: { aiSummary: Record<string, unknown> }) {
  const socialStrategy = aiSummary.socialStrategy as Record<string, unknown>;
  const contentStrategy = aiSummary.contentStrategy as Record<string, unknown> | undefined;
  const platformRecommendations =
    (socialStrategy.platformRecommendations as Array<Record<string, unknown>> | undefined) || [];
  const contentCalendarIdeas = (socialStrategy.contentCalendarIdeas as string[] | undefined) || [];
  const topicOpportunities = (contentStrategy?.topicOpportunities as string[] | undefined) || [];

  return (
    <div className="space-y-5">
      <p className="text-muted-foreground leading-relaxed">
        {String(socialStrategy.overallAssessment || "")}
      </p>
      <div className="grid gap-4 md:grid-cols-2">
        {platformRecommendations.slice(0, 4).map((platform, i) => (
          <div key={i} className="rounded-lg border bg-slate-50 p-4">
            <div className="flex items-center justify-between gap-3">
              <p className="font-semibold text-primary">{String(platform.platform || "Channel")}</p>
              <span className="text-xs font-semibold text-accent">{String(platform.priority || "MEDIUM")}</span>
            </div>
            <p className="mt-2 text-sm text-muted-foreground">{String(platform.currentState || "")}</p>
            <ul className="mt-3 list-disc space-y-1 pl-5 text-sm">
              {((platform.recommendations as string[] | undefined) || []).slice(0, 3).map((item, itemIndex) => (
                <li key={itemIndex}>{item}</li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      {[...topicOpportunities, ...contentCalendarIdeas].length > 0 && (
        <div>
          <p className="font-semibold text-primary">Content plays to run next</p>
          <ul className="mt-2 list-disc space-y-1 pl-5 text-sm">
            {[...topicOpportunities, ...contentCalendarIdeas].slice(0, 8).map((idea, i) => (
              <li key={i}>{idea}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

function FindingCard({
  finding,
}: {
  finding: {
    severity: string;
    title: string;
    description: string;
    impact: string;
    howToFix: string;
    affectedCount: number;
    serviceId?: string;
    serviceCta?: string;
  };
}) {
  const severityIcons = {
    CRITICAL: AlertTriangle,
    WARNING: AlertCircle,
    INFO: Info,
  };
  const Icon = severityIcons[finding.severity as keyof typeof severityIcons] || Info;

  return (
    <div
      className={cn(
        "p-4 rounded-lg border",
        getSeverityColor(finding.severity)
      )}
    >
      <div className="flex items-start gap-3">
        <Icon className="w-5 h-5 flex-shrink-0 mt-0.5" />
        <div className="flex-1">
          <h4 className="font-semibold">{finding.title}</h4>
          <p className="text-sm mt-1 opacity-90">{finding.description}</p>

          <div className="mt-3 space-y-2 text-sm">
            <div>
              <strong>Impact:</strong> {finding.impact}
            </div>
            <div>
              <strong>How to fix:</strong> {finding.howToFix}
            </div>
            {finding.affectedCount > 1 && (
              <div>
                <strong>Affected:</strong> {finding.affectedCount} pages
              </div>
            )}
          </div>

          {finding.serviceId && (
            <div className="mt-4 p-3 bg-accent/10 rounded-lg border border-accent/20">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-accent">
                  {finding.serviceCta}
                </p>
                <Button variant="accent" size="sm">
                  Learn More
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
