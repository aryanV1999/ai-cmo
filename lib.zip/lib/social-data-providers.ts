/**
 * Social data provider integrations.
 *
 * SocialData is used for X/Twitter because it exposes reliable profile metrics.
 * Apify is used for multi-platform profile scraping when APIFY_API_TOKEN is set.
 */

import {
  extractUsernameFromSocialUrl,
  type SocialPost,
  type SocialProfile,
  type SocialProfileMetrics,
} from "./brand-research";

type AnyRecord = Record<string, unknown>;

export async function enrichSocialProfiles(
  profiles: SocialProfile[]
): Promise<SocialProfile[]> {
  const enriched = profiles.map((profile) => ({
    ...profile,
    username: profile.username || extractUsernameFromSocialUrl(profile.url),
  }));

  const [socialDataProfiles, apifyProfiles] = await Promise.all([
    enrichWithSocialData(enriched),
    enrichWithApify(enriched),
  ]);

  return mergeProfileMetrics(enriched, socialDataProfiles, apifyProfiles);
}

async function enrichWithSocialData(
  profiles: SocialProfile[]
): Promise<Map<string, SocialProfileMetrics>> {
  const metrics = new Map<string, SocialProfileMetrics>();
  const apiKey = process.env.SOCIALDATA_API_KEY;
  if (!apiKey) return metrics;

  const xProfiles = profiles.filter((profile) =>
    profile.platform === "X/Twitter" && profile.username
  );

  await Promise.all(xProfiles.map(async (profile) => {
    try {
      const response = await fetch(
        `https://api.socialdata.tools/twitter/user/${encodeURIComponent(profile.username!)}`,
        {
          headers: {
            "Authorization": `Bearer ${apiKey}`,
            "Accept": "application/json",
          },
        }
      );

      if (!response.ok) return;
      const data = await response.json() as AnyRecord;
      const userId = stringLike(data.id_str) || stringLike(data.id);
      const sampledPosts = userId ? await fetchSocialDataTweets(userId, apiKey) : [];
      const followers = numberFrom(data.followers_count);
      const avgLikes = averagePostMetric(sampledPosts, "likes");
      const avgComments = averagePostMetric(sampledPosts, "comments");
      const avgViews = averagePostMetric(sampledPosts, "views");

      metrics.set(profileKey(profile), compactMetrics({
        followers,
        following: numberFrom(data.friends_count),
        posts: numberFrom(data.statuses_count),
        recentPosts: sampledPosts.length || undefined,
        avgEngagementRate: followers && followers > 0 && (avgLikes || avgComments)
          ? ((avgLikes || 0) + (avgComments || 0)) / followers
          : undefined,
        avgLikes,
        avgComments,
        avgViews,
        verified: Boolean(data.verified),
        bio: stringFrom(data.description),
        sampledPosts: sampledPosts.length > 0 ? sampledPosts : undefined,
        dataSource: "socialdata",
      }));
    } catch {
      // Keep audit running even when an external provider fails.
    }
  }));

  return metrics;
}

async function fetchSocialDataTweets(
  userId: string,
  apiKey: string
): Promise<SocialPost[]> {
  try {
    const response = await fetch(
      `https://api.socialdata.tools/twitter/user/${encodeURIComponent(userId)}/tweets`,
      {
        headers: {
          "Authorization": `Bearer ${apiKey}`,
          "Accept": "application/json",
        },
      }
    );

    if (!response.ok) return [];
    const data = await response.json() as AnyRecord | AnyRecord[];
    const tweets = Array.isArray(data)
      ? data
      : firstArray(data, ["tweets", "data", "items", "results"]);

    return (tweets || [])
      .filter(isRecord)
      .map(normalizePost)
      .filter((post) => post.text || post.createdAt || post.likes !== undefined || post.comments !== undefined)
      .slice(0, Number(process.env.SOCIAL_RECENT_POST_LIMIT || 20));
  } catch {
    return [];
  }
}

async function enrichWithApify(
  profiles: SocialProfile[]
): Promise<Map<string, SocialProfileMetrics>> {
  const metrics = new Map<string, SocialProfileMetrics>();
  const token = process.env.APIFY_API_TOKEN;
  if (!token) return metrics;

  const input = buildApifySocialInput(profiles);
  if (Object.keys(input).length === 0) return metrics;

  const actorId = process.env.APIFY_SOCIAL_PROFILE_ACTOR_ID || "aaether/social-scraper";
  const apiActorId = actorId.replace("/", "~");
  const url = `https://api.apify.com/v2/acts/${apiActorId}/run-sync-get-dataset-items?token=${encodeURIComponent(token)}`;

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...input,
        maxRecentPosts: Number(process.env.SOCIAL_RECENT_POST_LIMIT || 10),
        youtubeApiKey: process.env.YOUTUBE_API_KEY || undefined,
      }),
    });

    if (!response.ok) return metrics;
    const items = await response.json() as AnyRecord[];
    const combined = Object.assign({}, ...items);

    for (const profile of profiles) {
      const platformKey = apifyPlatformKey(profile.platform);
      if (!platformKey) continue;

      const platformData = pickPlatformData(combined, platformKey);
      if (!platformData) continue;
      const sampledPosts = extractSampledPosts(platformData);
      const avgLikes = firstNumber(platformData, ["avgLikes", "averageLikes"])
        ?? averagePostMetric(sampledPosts, "likes");
      const avgComments = firstNumber(platformData, ["avgComments", "averageComments"])
        ?? averagePostMetric(sampledPosts, "comments");
      const avgViews = firstNumber(platformData, ["avgViews", "averageViews"])
        ?? averagePostMetric(sampledPosts, "views");

      metrics.set(profileKey(profile), compactMetrics({
        followers: firstNumber(platformData, ["followers", "followersCount", "followerCount", "subscribers", "subscriberCount"]),
        following: firstNumber(platformData, ["following", "followingCount"]),
        posts: firstNumber(platformData, ["posts", "postsCount", "videoCount", "statusesCount"]),
        recentPosts: sampledPosts.length || firstArrayLength(platformData, ["recentPosts", "posts", "videos", "items"]),
        avgEngagementRate: firstNumber(platformData, ["avgEngagementRate", "engagementRate"]),
        avgLikes,
        avgComments,
        avgViews,
        verified: firstBoolean(platformData, ["verified", "isVerified"]),
        bio: firstString(platformData, ["bio", "description", "biography"]),
        sampledPosts: sampledPosts.length > 0 ? sampledPosts : undefined,
        dataSource: "apify",
      }));
    }
  } catch {
    return metrics;
  }

  return metrics;
}

function buildApifySocialInput(profiles: SocialProfile[]): Record<string, string> {
  const input: Record<string, string> = {};

  for (const profile of profiles) {
    const username = profile.username || extractUsernameFromSocialUrl(profile.url);
    if (!username) continue;

    if (profile.platform === "Instagram") input.instagram = username;
    if (profile.platform === "TikTok") input.tiktok = username;
    if (profile.platform === "YouTube") input.youtube = username.startsWith("@") ? username : profile.url;
    if (profile.platform === "X/Twitter") input.twitter = username;
  }

  return input;
}

function mergeProfileMetrics(
  baseProfiles: SocialProfile[],
  socialData: Map<string, SocialProfileMetrics>,
  apify: Map<string, SocialProfileMetrics>
): SocialProfile[] {
  return baseProfiles.map((profile) => {
    const key = profileKey(profile);
    const apifyMetrics = apify.get(key);
    const socialDataMetrics = socialData.get(key);
    const mergedMetrics = mergeMetrics(apifyMetrics, socialDataMetrics);

    return {
      ...profile,
      metrics: mergedMetrics,
      confidence: apifyMetrics || socialDataMetrics
        ? Math.max(profile.confidence, 92)
        : profile.confidence,
    };
  });
}

function profileKey(profile: SocialProfile): string {
  return `${profile.platform}:${profile.username || extractUsernameFromSocialUrl(profile.url) || profile.url}`.toLowerCase();
}

function apifyPlatformKey(platform: string): string | null {
  if (platform === "Instagram") return "instagram";
  if (platform === "TikTok") return "tiktok";
  if (platform === "YouTube") return "youtube";
  if (platform === "X/Twitter") return "twitter";
  return null;
}

function pickPlatformData(data: AnyRecord, platformKey: string): AnyRecord | null {
  const direct = data[platformKey];
  if (isRecord(direct)) return direct;

  const candidates = Object.values(data).filter(isRecord);
  return candidates.find((candidate) =>
    String(candidate.platform || candidate.type || "").toLowerCase().includes(platformKey)
  ) || null;
}

function numberFrom(value: unknown): number | undefined {
  const num = typeof value === "number" ? value : Number(value);
  return Number.isFinite(num) ? num : undefined;
}

function stringFrom(value: unknown): string | undefined {
  return typeof value === "string" && value.trim() ? value : undefined;
}

function firstNumber(data: AnyRecord, keys: string[]): number | undefined {
  for (const key of keys) {
    const value = numberFrom(data[key]);
    if (value !== undefined) return value;
  }
  return undefined;
}

function firstString(data: AnyRecord, keys: string[]): string | undefined {
  for (const key of keys) {
    const value = stringFrom(data[key]);
    if (value !== undefined) return value;
  }
  return undefined;
}

function firstBoolean(data: AnyRecord, keys: string[]): boolean | undefined {
  for (const key of keys) {
    if (typeof data[key] === "boolean") return data[key] as boolean;
  }
  return undefined;
}

function firstArrayLength(data: AnyRecord, keys: string[]): number | undefined {
  for (const key of keys) {
    if (Array.isArray(data[key])) return (data[key] as unknown[]).length;
  }
  return undefined;
}

function isRecord(value: unknown): value is AnyRecord {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function compactMetrics(metrics: SocialProfileMetrics): SocialProfileMetrics {
  return Object.fromEntries(
    Object.entries(metrics).filter(([, value]) => value !== undefined && value !== "")
  ) as SocialProfileMetrics;
}

function mergeMetrics(
  apifyMetrics?: SocialProfileMetrics,
  socialDataMetrics?: SocialProfileMetrics
): SocialProfileMetrics | undefined {
  if (!apifyMetrics && !socialDataMetrics) return undefined;

  const merged = compactMetrics({
    ...apifyMetrics,
    ...socialDataMetrics,
    recentPosts: apifyMetrics?.recentPosts ?? socialDataMetrics?.recentPosts,
    avgEngagementRate: apifyMetrics?.avgEngagementRate ?? socialDataMetrics?.avgEngagementRate,
    avgLikes: apifyMetrics?.avgLikes ?? socialDataMetrics?.avgLikes,
    avgComments: apifyMetrics?.avgComments ?? socialDataMetrics?.avgComments,
    avgViews: apifyMetrics?.avgViews ?? socialDataMetrics?.avgViews,
    sampledPosts: apifyMetrics?.sampledPosts ?? socialDataMetrics?.sampledPosts,
    dataSource: [socialDataMetrics?.dataSource, apifyMetrics?.dataSource]
      .filter(Boolean)
      .filter((value, index, all) => all.indexOf(value) === index)
      .join(", ") as SocialProfileMetrics["dataSource"],
  });

  return merged.dataSource ? merged : undefined;
}

function extractSampledPosts(data: AnyRecord): SocialPost[] {
  const posts = firstArray(data, ["recentPosts", "posts", "videos", "items", "latestPosts"]);
  if (!posts) return [];

  return posts
    .filter(isRecord)
    .map(normalizePost)
    .filter((post) => post.text || post.createdAt || post.likes !== undefined || post.comments !== undefined)
    .slice(0, Number(process.env.SOCIAL_RECENT_POST_LIMIT || 20));
}

function normalizePost(post: AnyRecord): SocialPost {
  const text = firstString(post, [
    "caption",
    "text",
    "full_text",
    "description",
    "title",
    "postText",
    "message",
  ]);
  const createdAt = firstString(post, [
    "createdAt",
    "tweet_created_at",
    "timestamp",
    "date",
    "postedAt",
    "publishedAt",
    "uploadDate",
    "takenAt",
  ]);
  const type = firstString(post, [
    "type",
    "mediaType",
    "contentType",
    "productType",
    "format",
  ]);

  return compactPost({
    id: firstString(post, ["id", "postId", "shortCode", "code"]),
    url: firstString(post, ["url", "postUrl", "link", "permalink"]),
    text,
    type,
    createdAt,
    likes: firstNumber(post, ["likes", "likeCount", "likesCount", "diggCount", "favorite_count", "favoriteCount"]),
    comments: firstNumber(post, ["comments", "commentCount", "commentsCount", "reply_count"]),
    views: firstNumber(post, ["views", "viewCount", "playCount", "videoViewCount", "views_count"]),
    shares: firstNumber(post, ["shares", "shareCount", "sharesCount", "retweet_count", "quote_count"]),
    replies: firstNumber(post, ["replies", "replyCount", "authorReplyCount", "reply_count"]),
    hashtags: extractHashtags(post, text),
  });
}

function extractHashtags(post: AnyRecord, text?: string): string[] {
  const rawTags = firstArray(post, ["hashtags", "tags"]);
  const tags = new Set<string>();

  if (rawTags) {
    for (const tag of rawTags) {
      if (typeof tag === "string") tags.add(cleanHashtag(tag));
      if (isRecord(tag)) {
        const value = firstString(tag, ["name", "tag", "text"]);
        if (value) tags.add(cleanHashtag(value));
      }
    }
  }

  for (const match of text?.match(/#[A-Za-z0-9_]+/g) || []) {
    tags.add(cleanHashtag(match));
  }

  return Array.from(tags).filter(Boolean).slice(0, 12);
}

function cleanHashtag(value: string): string {
  return value.replace(/^#/, "").trim().toLowerCase();
}

function stringLike(value: unknown): string | undefined {
  if (typeof value === "string" && value.trim()) return value;
  if (typeof value === "number" && Number.isFinite(value)) return String(value);
  return undefined;
}

function firstArray(data: AnyRecord, keys: string[]): unknown[] | undefined {
  for (const key of keys) {
    if (Array.isArray(data[key])) return data[key] as unknown[];
  }
  return undefined;
}

function averagePostMetric(posts: SocialPost[], key: "likes" | "comments" | "views"): number | undefined {
  const values = posts
    .map((post) => post[key])
    .filter((value): value is number => typeof value === "number" && Number.isFinite(value));
  if (values.length === 0) return undefined;
  return Math.round(values.reduce((sum, value) => sum + value, 0) / values.length);
}

function compactPost(post: SocialPost): SocialPost {
  return Object.fromEntries(
    Object.entries(post).filter(([, value]) => {
      if (value === undefined || value === "") return false;
      if (Array.isArray(value) && value.length === 0) return false;
      return true;
    })
  ) as SocialPost;
}
