/**
 * Competitor Analysis Module
 * Compares user site against competitors on key SEO/market signals
 */

import { discoverCompetitorDomains, normalizeDomain } from "../brand-research";

export interface CompetitorData {
  domain: string;
  source?: "seo-api" | "web-discovered" | "gemini-assisted" | "estimated";
  confidence?: number;
  metricsAvailable?: boolean;
  domainAuthority: number;
  domainRating: number;
  totalBacklinks: number;
  referringDomains: number;
  organicTraffic: number;
  organicKeywords: number;
  topKeywords: Keyword[];
  contentVelocity: number; // Posts per month (estimated)
}

export interface Keyword {
  keyword: string;
  position: number;
  volume: number;
  difficulty: number;
  url: string;
}

export interface CompetitorComparison {
  metric: string;
  userValue: number | string;
  competitors: { domain: string; value: number | string }[];
  winner: string;
  gap: string;
  recommendation: string;
}

export interface CompetitorFinding {
  type: string;
  severity: "CRITICAL" | "WARNING" | "INFO";
  title: string;
  description: string;
  impact: string;
  howToFix: string;
  data?: Record<string, unknown>;
  score: number;
}

export interface CompetitorResult {
  score: number;
  dataQuality: "seo-api" | "web-discovered" | "estimated" | "unavailable";
  notes: string[];
  userSite: CompetitorData;
  competitors: CompetitorData[];
  comparisons: CompetitorComparison[];
  findings: CompetitorFinding[];
  keywordGap: {
    competitorOnlyKeywords: Keyword[];
    sharedKeywords: Keyword[];
    userOnlyKeywords: Keyword[];
  };
  summary: {
    competitivePosition: "leading" | "competitive" | "lagging" | "far-behind";
    primaryGaps: string[];
    quickWins: string[];
  };
}

/**
 * Analyze competitors and compare to user site
 * Note: In production, this would integrate with SEMrush/Ahrefs API
 */
export async function analyzeCompetitors(
  userDomain: string,
  competitorDomains: string[],
  _apiKey?: string
): Promise<CompetitorResult> {
  const normalizedUserDomain = normalizeDomain(userDomain);
  const cleanCompetitorDomains = Array.from(new Set(
    competitorDomains
      .map(normalizeDomain)
      .filter((d) => d && d !== normalizedUserDomain && !d.endsWith(`.${normalizedUserDomain}`))
  ));

  const source = process.env.GEMINI_API_KEY ? "gemini-assisted" : "web-discovered";
  const userSite = await fetchDomainData(normalizedUserDomain, source);
  const competitors = await Promise.all(
    cleanCompetitorDomains.slice(0, 5).map((d) => fetchDomainData(d, source))
  );
  const notes = competitors.length === 0
    ? ["No competitor domains were found from Gemini-assisted public research. Add known competitors or connect a search/SEO data API for deeper analysis."]
    : [
        process.env.GEMINI_API_KEY
          ? "Competitors are Gemini-assisted from public research and page context. Quantitative SEO metrics still require SEMrush/Ahrefs/Similarweb credentials."
          : "Competitors are web-discovered. Authority, traffic, backlink, and keyword metrics require SEMrush/Ahrefs/Similarweb API credentials.",
      ];

  // Generate comparisons
  const comparisons = generateComparisons(userSite, competitors);

  // Generate findings
  const findings = generateCompetitorFindings(userSite, competitors, comparisons);

  // Analyze keyword gaps
  const keywordGap = analyzeKeywordGap(userSite, competitors);

  // Calculate overall score and competitive position
  const { score, position, primaryGaps, quickWins } = calculateCompetitiveScore(
    userSite,
    competitors
  );

  return {
    score,
    dataQuality: _apiKey ? "seo-api" : competitors.length > 0 ? "web-discovered" : "unavailable",
    notes,
    userSite,
    competitors,
    comparisons,
    findings,
    keywordGap,
    summary: {
      competitivePosition: position,
      primaryGaps,
      quickWins,
    },
  };
}

async function fetchDomainData(
  domain: string,
  source: CompetitorData["source"] = "web-discovered"
): Promise<CompetitorData> {
  return {
    domain,
    source,
    confidence: source === "web-discovered" ? 70 : 50,
    metricsAvailable: false,
    domainAuthority: 0,
    domainRating: 0,
    totalBacklinks: 0,
    referringDomains: 0,
    organicTraffic: 0,
    organicKeywords: 0,
    topKeywords: [],
    contentVelocity: 0,
  };
}

function generateComparisons(
  user: CompetitorData,
  competitors: CompetitorData[]
): CompetitorComparison[] {
  const comparisons: CompetitorComparison[] = [];
  const metricsAvailable = [user, ...competitors].some((c) => c.metricsAvailable);

  if (competitors.length === 0) {
    return [];
  }

  if (!metricsAvailable) {
    return [
      {
        metric: "Competitor discovery",
        userValue: user.domain,
        competitors: competitors.map((c) => ({ domain: c.domain, value: "found via web research" })),
        winner: "Not available",
        gap: "Quantitative SEO metrics unavailable",
        recommendation: "Connect SEMrush, Ahrefs, Similarweb, or Google Search Console data to compare authority, traffic, keyword, and backlink gaps.",
      },
    ];
  }

  // Domain Authority comparison
  const allDA = [user, ...competitors].map((c) => ({
    domain: c.domain,
    value: c.domainAuthority,
  }));
  const maxDA = Math.max(...allDA.map((a) => a.value));
  const daWinner = allDA.find((a) => a.value === maxDA)!.domain;
  const daGap = maxDA - user.domainAuthority;

  comparisons.push({
    metric: "Domain Authority",
    userValue: user.domainAuthority,
    competitors: competitors.map((c) => ({
      domain: c.domain,
      value: c.domainAuthority,
    })),
    winner: daWinner,
    gap: daGap > 0 ? `${daGap} points behind leader` : "You're the leader",
    recommendation:
      daGap > 20
        ? "Focus on building high-quality backlinks to close the DA gap"
        : "Maintain your link building efforts",
  });

  // Backlinks comparison
  const allBacklinks = [user, ...competitors].map((c) => ({
    domain: c.domain,
    value: c.referringDomains,
  }));
  const maxBacklinks = Math.max(...allBacklinks.map((a) => a.value as number));
  const blWinner = allBacklinks.find((a) => a.value === maxBacklinks)!.domain;
  const blGap = maxBacklinks - user.referringDomains;

  comparisons.push({
    metric: "Referring Domains",
    userValue: user.referringDomains,
    competitors: competitors.map((c) => ({
      domain: c.domain,
      value: c.referringDomains,
    })),
    winner: blWinner,
    gap: blGap > 0 ? `${blGap} fewer linking sites` : "You're the leader",
    recommendation:
      blGap > 100
        ? "Prioritize link building campaigns and digital PR"
        : "Continue steady link acquisition",
  });

  // Organic keywords comparison
  const allKeywords = [user, ...competitors].map((c) => ({
    domain: c.domain,
    value: c.organicKeywords,
  }));
  const maxKeywords = Math.max(...allKeywords.map((a) => a.value as number));
  const kwWinner = allKeywords.find((a) => a.value === maxKeywords)!.domain;
  const kwGap = maxKeywords - user.organicKeywords;

  comparisons.push({
    metric: "Organic Keywords",
    userValue: user.organicKeywords,
    competitors: competitors.map((c) => ({
      domain: c.domain,
      value: c.organicKeywords,
    })),
    winner: kwWinner,
    gap: kwGap > 0 ? `${kwGap} fewer ranking keywords` : "You're the leader",
    recommendation:
      kwGap > 500
        ? "Expand content to target more keywords"
        : "Focus on improving existing keyword positions",
  });

  // Content velocity comparison
  const allVelocity = [user, ...competitors].map((c) => ({
    domain: c.domain,
    value: c.contentVelocity,
  }));
  const maxVelocity = Math.max(...allVelocity.map((a) => a.value as number));
  const cvWinner = allVelocity.find((a) => a.value === maxVelocity)!.domain;
  const cvGap = maxVelocity - user.contentVelocity;

  comparisons.push({
    metric: "Content Velocity (posts/month)",
    userValue: user.contentVelocity,
    competitors: competitors.map((c) => ({
      domain: c.domain,
      value: c.contentVelocity,
    })),
    winner: cvWinner,
    gap: cvGap > 0 ? `${cvGap} fewer posts per month` : "You're the leader",
    recommendation:
      cvGap > 4
        ? "Increase content production to match competitor pace"
        : "Maintain current publishing schedule",
  });

  return comparisons;
}

function generateCompetitorFindings(
  user: CompetitorData,
  competitors: CompetitorData[],
  comparisons: CompetitorComparison[]
): CompetitorFinding[] {
  const findings: CompetitorFinding[] = [];
  if (competitors.length === 0) {
    findings.push({
      type: "competitor_research_unavailable",
      severity: "INFO",
      title: "Competitor research needs more data",
      description: "No reliable competitor domains were discovered from public web research.",
      impact: "Competitive advantages and disadvantages cannot be quantified without real competitor inputs.",
      howToFix: "Add known competitors manually or connect a search/SEO intelligence API.",
      score: 50,
    });
    return findings;
  }

  if (![user, ...competitors].some((c) => c.metricsAvailable)) {
    findings.push({
      type: "competitors_discovered_metrics_unavailable",
      severity: "INFO",
      title: `${competitors.length} likely competitors discovered`,
      description: `Found likely competitors: ${competitors.map(c => c.domain).join(", ")}. Quantitative SEO metrics are not available without an external SEO data API.`,
      impact: "You can review market positioning, but authority, backlink, traffic, and keyword advantages cannot be scored accurately yet.",
      howToFix: "Connect SEMrush/Ahrefs/Similarweb or pass known competitor metrics into the analyzer.",
      score: 70,
    });
    return findings;
  }

  const avgCompetitorDA =
    competitors.reduce((sum, c) => sum + c.domainAuthority, 0) / competitors.length;
  const avgCompetitorBacklinks =
    competitors.reduce((sum, c) => sum + c.referringDomains, 0) / competitors.length;

  // Domain Authority gap
  const daGap = avgCompetitorDA - user.domainAuthority;
  if (daGap > 20) {
    findings.push({
      type: "large_da_gap",
      severity: "CRITICAL",
      title: `Your Domain Authority is ${Math.round(daGap)} points below competitor average`,
      description: `Your DA of ${user.domainAuthority} is significantly lower than the competitor average of ${Math.round(avgCompetitorDA)}.`,
      impact:
        "Lower domain authority means your pages will struggle to outrank competitors for valuable keywords.",
      howToFix:
        "Implement an aggressive link building strategy: guest posting, digital PR, creating linkable assets, and building industry relationships.",
      score: Math.max(0, 100 - daGap * 2),
      data: { userDA: user.domainAuthority, avgCompetitorDA },
    });
  } else if (daGap > 10) {
    findings.push({
      type: "moderate_da_gap",
      severity: "WARNING",
      title: `Your Domain Authority trails competitors by ${Math.round(daGap)} points`,
      description: `At ${user.domainAuthority} DA, you're within striking distance of competitors averaging ${Math.round(avgCompetitorDA)}.`,
      impact: "Closing this gap will improve your competitive position for target keywords.",
      howToFix:
        "Focus on quality over quantity for backlinks. Target authoritative sites in your niche.",
      score: Math.max(0, 100 - daGap * 3),
    });
  }

  // Backlink gap
  const blGap =
    (avgCompetitorBacklinks - user.referringDomains) / avgCompetitorBacklinks;
  if (blGap > 0.5) {
    findings.push({
      type: "large_backlink_gap",
      severity: "CRITICAL",
      title: `Competitors have ${Math.round(blGap * 100)}% more referring domains`,
      description: `You have ${user.referringDomains} referring domains vs competitor average of ${Math.round(avgCompetitorBacklinks)}.`,
      impact:
        "Fewer backlinks = less authority signals to Google. You'll struggle to rank for competitive terms.",
      howToFix:
        "Launch link building campaigns: create original research, build tools, run digital PR campaigns, and pursue quality guest posting opportunities.",
      score: Math.max(0, 100 - blGap * 100),
    });
  }

  // Keyword coverage
  const avgCompetitorKw =
    competitors.reduce((sum, c) => sum + c.organicKeywords, 0) / competitors.length;
  const kwGap = (avgCompetitorKw - user.organicKeywords) / avgCompetitorKw;
  if (kwGap > 0.5) {
    findings.push({
      type: "keyword_coverage_gap",
      severity: "WARNING",
      title: `Competitors rank for ${Math.round(kwGap * 100)}% more keywords`,
      description: `You rank for ${user.organicKeywords} keywords vs competitor average of ${Math.round(avgCompetitorKw)}.`,
      impact:
        "Limited keyword coverage means you're missing traffic opportunities across your market.",
      howToFix:
        "Conduct keyword research to find gaps. Create content targeting long-tail and related keywords you're not covering.",
      score: Math.max(0, 100 - kwGap * 80),
    });
  }

  // Content velocity
  const avgVelocity =
    competitors.reduce((sum, c) => sum + c.contentVelocity, 0) / competitors.length;
  if (user.contentVelocity < avgVelocity * 0.5) {
    findings.push({
      type: "low_content_velocity",
      severity: "WARNING",
      title: "Competitors are outpacing your content production",
      description: `You publish ~${user.contentVelocity} posts/month vs competitor average of ~${Math.round(avgVelocity)}.`,
      impact:
        "Lower content velocity means fewer opportunities to rank and slower domain growth.",
      howToFix:
        "Increase content production. Consider hiring writers, creating content calendars, and repurposing existing content.",
      score: Math.max(0, (user.contentVelocity / avgVelocity) * 100),
    });
  }

  return findings;
}

function analyzeKeywordGap(
  user: CompetitorData,
  competitors: CompetitorData[]
): CompetitorResult["keywordGap"] {
  if (competitors.length === 0) {
    return { competitorOnlyKeywords: [], sharedKeywords: [], userOnlyKeywords: [] };
  }
  const userKeywords = new Set(user.topKeywords.map((k) => k.keyword));
  const competitorKeywords = new Set(
    competitors.flatMap((c) => c.topKeywords.map((k) => k.keyword))
  );

  const competitorOnlyKeywords = competitors
    .flatMap((c) => c.topKeywords)
    .filter((k) => !userKeywords.has(k.keyword))
    .filter(
      (k, i, arr) => arr.findIndex((a) => a.keyword === k.keyword) === i
    );

  const sharedKeywords = user.topKeywords.filter((k) =>
    competitorKeywords.has(k.keyword)
  );

  const userOnlyKeywords = user.topKeywords.filter(
    (k) => !competitorKeywords.has(k.keyword)
  );

  return {
    competitorOnlyKeywords,
    sharedKeywords,
    userOnlyKeywords,
  };
}

function calculateCompetitiveScore(
  user: CompetitorData,
  competitors: CompetitorData[]
): {
  score: number;
  position: "leading" | "competitive" | "lagging" | "far-behind";
  primaryGaps: string[];
  quickWins: string[];
} {
  if (competitors.length === 0) {
    return {
      score: 50,
      position: "competitive",
      primaryGaps: ["Competitor dataset unavailable"],
      quickWins: ["Add known competitor domains or connect SEO data"],
    };
  }

  if (![user, ...competitors].some((c) => c.metricsAvailable)) {
    return {
      score: 50,
      position: "competitive",
      primaryGaps: ["Authority, backlink, traffic, and keyword metrics unavailable"],
      quickWins: [
        "Review discovered competitor websites manually",
        "Connect SEO intelligence data for quantitative gap analysis",
      ],
    };
  }

  const avgCompetitor = {
    da: competitors.reduce((sum, c) => sum + c.domainAuthority, 0) / competitors.length,
    backlinks:
      competitors.reduce((sum, c) => sum + c.referringDomains, 0) / competitors.length,
    keywords:
      competitors.reduce((sum, c) => sum + c.organicKeywords, 0) / competitors.length,
  };

  // Score based on relative position
  const daScore = Math.min(100, (user.domainAuthority / avgCompetitor.da) * 100);
  const blScore = Math.min(100, (user.referringDomains / avgCompetitor.backlinks) * 100);
  const kwScore = Math.min(100, (user.organicKeywords / avgCompetitor.keywords) * 100);

  const overallScore = Math.round((daScore + blScore + kwScore) / 3);

  let position: "leading" | "competitive" | "lagging" | "far-behind";
  if (overallScore >= 100) position = "leading";
  else if (overallScore >= 70) position = "competitive";
  else if (overallScore >= 40) position = "lagging";
  else position = "far-behind";

  const primaryGaps: string[] = [];
  const quickWins: string[] = [];

  if (daScore < 70) primaryGaps.push("Domain Authority");
  if (blScore < 70) primaryGaps.push("Backlink Profile");
  if (kwScore < 70) primaryGaps.push("Keyword Coverage");

  if (user.contentVelocity < 4) quickWins.push("Increase content production");
  if (kwScore > daScore) quickWins.push("Build more backlinks to leverage keyword coverage");
  if (daScore > kwScore) quickWins.push("Create more content to leverage domain authority");

  return {
    score: overallScore,
    position,
    primaryGaps,
    quickWins,
  };
}

/**
 * Auto-detect likely competitors based on industry/keywords
 */
export async function detectCompetitors(
  domain: string,
  contextTerms: string[] = []
): Promise<string[]> {
  return discoverCompetitorDomains(domain, contextTerms);
}
