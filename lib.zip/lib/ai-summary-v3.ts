/**
 * AI Summary V3 - RAG-Enhanced Report Generation
 * 
 * Generates premium CMO-quality reports using:
 * - Retrieval-Augmented Generation (RAG)
 * - Knowledge base of SEO best practices
 * - Fix templates with step-by-step instructions
 * - Industry benchmarks and competitor insights
 * - GEO/AI visibility recommendations
 */

import { OpenAI } from "openai";
import {
  getAuditRAGContext,
  type Finding,
  type ContextBundle,
  type Citation,
} from "./rag";
import { type CompetitorResult } from "./analyzers/competitors";
import { type ChannelResultV2 } from "./analyzers/channels-v2";

// ─────────────────────────────────────────
// TYPES
// ─────────────────────────────────────────

export interface AuditData {
  domain: string;
  industry?: string;
  findings: Finding[];
  pageSpeedMetrics?: PageSpeedMetrics;
  geoVisibility?: GEOVisibility;
  crawledPages?: CrawledPage[];
  linkGraph?: LinkGraphData;
  competitors?: CompetitorResult;
  channels?: ChannelResultV2;
}

export interface PageSpeedMetrics {
  performance: number;
  lcp: number;
  cls: number;
  fid: number;
  fcp: number;
  ttfb: number;
}

export interface GEOVisibility {
  overallScore: number;
  providers: {
    name: string;
    mentioned: boolean;
    sentiment: string;
    citations: number;
    context?: string;
  }[];
}

export interface CrawledPage {
  url: string;
  title?: string;
  statusCode: number;
  issues: string[];
}

export interface LinkGraphData {
  totalInternalLinks: number;
  orphanPages: number;
  avgClickDepth: number;
  topLinkedPages: { url: string; inbound: number }[];
}

// ─────────────────────────────────────────
// OUTPUT TYPES
// ─────────────────────────────────────────

export interface CMOReport {
  // Executive Summary
  executiveSummary: ExecutiveSummary;
  
  // Scores
  overallScore: number;
  categoryScores: CategoryScores;
  
  // Prioritized Actions
  immediateActions: ActionItem[];
  weeklyBacklog: ActionItem[];
  strategicInitiatives: ActionItem[];
  
  // Deep Dives
  technicalSEO: CategoryAnalysis;
  contentStrategy: ContentStrategy;
  geoStrategy: GEOStrategy;
  competitorInsights: CompetitorInsights;
  socialStrategy: SocialStrategy;
  
  // Growth Plan
  contentGrowthPlan: ContentGrowthPlan;
  
  // Citations
  citations: Citation[];
  
  // Meta
  generatedAt: string;
  ragContextUsed: boolean;
  tokensUsed: number;
}

export interface ExecutiveSummary {
  headline: string;
  currentState: string;
  topOpportunity: string;
  expectedImpact: string;
  timeToValue: string;
}

export interface CategoryScores {
  technicalSEO: number;
  onPageSEO: number;
  performance: number;
  geoVisibility: number;
  contentQuality: number;
  linkHealth: number;
}

export interface ActionItem {
  id: string;
  title: string;
  description: string;
  priority: "CRITICAL" | "HIGH" | "MEDIUM" | "LOW";
  effort: "QUICK_WIN" | "MODERATE" | "SIGNIFICANT" | "MAJOR_PROJECT";
  impact: string;
  category: string;
  affectedPages: string[];
  implementationSteps: string[];
  toolsNeeded: string[];
  expectedOutcome: string;
  deadline?: string;
}

export interface CategoryAnalysis {
  score: number;
  summary: string;
  strengths: string[];
  weaknesses: string[];
  recommendations: string[];
}

export interface ContentStrategy {
  currentAssessment: string;
  contentGaps: string[];
  topicOpportunities: string[];
  repurposingIdeas: RepurposingIdea[];
}

export interface RepurposingIdea {
  existingContent: string;
  newFormats: string[];
  targetPlatforms: string[];
  estimatedReach: string;
}

export interface GEOStrategy {
  currentVisibility: string;
  aiReadinessScore: number;
  recommendations: string[];
  contentEnhancements: string[];
  structuredDataNeeds: string[];
}

export interface CompetitorInsights {
  identifiedCompetitors: string[];
  competitorStrengths: string[];
  gapsToExploit: string[];
  differentiationOpportunities: string[];
}

export interface SocialStrategy {
  overallAssessment: string;
  executiveSummary?: string[];
  strengths?: string[];
  weaknesses?: string[];
  contentStrategyAnalysis?: string[];
  audienceEngagementAnalysis?: string[];
  brandConsistencyAnalysis?: string[];
  growthOpportunities?: string[];
  ninetyDayActionPlan?: string[];
  overallSocialMaturityScore?: number;
  scoreBreakdown?: Record<string, number>;
  platformRecommendations: PlatformRecommendation[];
  contentCalendarIdeas: string[];
  integrationOpportunities: string[];
}

export interface PlatformRecommendation {
  platform: string;
  priority: "HIGH" | "MEDIUM" | "LOW";
  currentState: string;
  recommendations: string[];
  contentTypes: string[];
}

export interface ContentGrowthPlan {
  thirtyDays: GrowthMilestone;
  sixtyDays: GrowthMilestone;
  ninetyDays: GrowthMilestone;
}

export interface GrowthMilestone {
  focus: string;
  deliverables: string[];
  expectedOutcomes: string[];
  kpis: string[];
}

// ─────────────────────────────────────────
// MAIN FUNCTION
// ─────────────────────────────────────────

function getOpenAIKey(): string {
  const geminiValue = process.env.GEMINI_API_KEY || "";
  return (
    process.env.OPENAI_API_KEY ||
    process.env.OPEN_API_KEY ||
    (geminiValue.startsWith("sk-") ? geminiValue : "")
  );
}

const openai = new OpenAI({
  apiKey: getOpenAIKey(),
});

export async function generateCMOReport(
  auditData: AuditData
): Promise<CMOReport> {
  console.log(`[AI Summary V3] Generating report for ${auditData.domain}`);
  
  // 1. Get RAG context
  let ragContext: ContextBundle | null = null;
  let ragPrompt = "";
  
  try {
    const { prompt, context } = await getAuditRAGContext(
      auditData.findings,
      auditData.domain,
      auditData.industry
    );
    ragContext = context;
    ragPrompt = prompt;
    console.log(`[AI Summary V3] RAG context retrieved: ${context.totalTokens} tokens, ${context.sourceCount} sources`);
  } catch (error) {
    console.warn("[AI Summary V3] RAG retrieval failed, proceeding without context:", error);
  }
  
  // 2. Build prompt
  const prompt = buildCMOPrompt(auditData, ragPrompt);
  
  // 3. Generate with OpenAI
  try {
    const response = await openai.chat.completions.create({
      model: process.env.OPENAI_CMO_MODEL || "gpt-4o",
      messages: [
        {
          role: "user",
          content: prompt,
        },
      ],
      temperature: 0.55,
      max_tokens: 8192,
      response_format: { type: "json_object" },
    });
    const text = response.choices[0]?.message?.content || "";
    
    // Parse JSON response
    const report = parseJsonReport(text) as Omit<CMOReport, 'citations' | 'generatedAt' | 'ragContextUsed' | 'tokensUsed'>;
    
    // Add metadata
    return {
      ...report,
      citations: ragContext?.citations || [],
      generatedAt: new Date().toISOString(),
      ragContextUsed: !!ragContext,
      tokensUsed: ragContext?.totalTokens || 0,
    };
  } catch (error) {
    console.error("[AI Summary V3] Generation failed:", error);
    return generateFallbackReport(auditData);
  }
}

function parseJsonReport(text: string): unknown {
  const trimmed = text.trim();
  const unfenced = trimmed
    .replace(/^```(?:json)?/i, "")
    .replace(/```$/i, "")
    .trim();

  try {
    return JSON.parse(unfenced);
  } catch {
    const start = unfenced.indexOf("{");
    const end = unfenced.lastIndexOf("}");
    if (start >= 0 && end > start) {
      return JSON.parse(unfenced.slice(start, end + 1));
    }
    throw new Error("Model did not return parseable JSON");
  }
}

// ─────────────────────────────────────────
// PROMPT BUILDING
// ─────────────────────────────────────────

function buildCMOPrompt(auditData: AuditData, ragContext: string): string {
  const {
    domain,
    industry,
    findings,
    pageSpeedMetrics,
    geoVisibility,
    crawledPages,
    linkGraph,
    competitors,
    channels,
  } = auditData;
  
  // Categorize findings
  const errors = findings.filter(f => f.severity === "ERROR" || f.severity === "CRITICAL");
  const warnings = findings.filter(f => f.severity === "WARNING");
  const opportunities = findings.filter(f => f.severity === "OPPORTUNITY");
  
  // Build findings summary
  const findingsSummary = findings.slice(0, 30).map(f => ({
    type: f.type,
    severity: f.severity,
    title: f.title,
    message: (f.message || f.description || f.title || "").slice(0, 260),
    impact: f.impact,
    howToFix: f.howToFix,
    affectedPages: (f.affectedPages || f.affectedUrls || []).slice(0, 5),
  }));

  const competitorEvidence = competitors ? {
    score: competitors.score,
    dataQuality: competitors.dataQuality,
    notes: competitors.notes,
    position: competitors.summary.competitivePosition,
    competitors: competitors.competitors.map(c => ({
      domain: c.domain,
      source: c.source,
      confidence: c.confidence,
      metricsAvailable: c.metricsAvailable,
      domainAuthority: c.domainAuthority,
      referringDomains: c.referringDomains,
      organicKeywords: c.organicKeywords,
      contentVelocity: c.contentVelocity,
    })),
    comparisons: competitors.comparisons,
    keywordGap: competitors.keywordGap.competitorOnlyKeywords.slice(0, 12),
    primaryGaps: competitors.summary.primaryGaps,
    quickWins: competitors.summary.quickWins,
  } : null;

  const channelEvidence = channels ? {
    score: channels.score,
    confidence: channels.confidence,
    summary: channels.summary,
    channels: channels.channels.map(c => ({
      channel: c.channel,
      status: c.status,
      quality: c.quality,
      details: c.details,
      metrics: c.metrics,
      recommendations: c.recommendations.slice(0, 3),
    })),
  } : null;

  const socialChannel = channels?.channels
    .find(c => c.channel.toLowerCase().includes("social"));
  const computedSocialAnalysis = socialChannel?.metrics?.socialAnalysis || null;
  const socialProfileEvidence = socialChannel?.metrics?.platform_health
    || socialChannel?.metrics?.profileBreakdown
    || [];

  const pageEvidence = (crawledPages || []).slice(0, 20).map(p => ({
    url: p.url,
    title: p.title,
    statusCode: p.statusCode,
    issues: p.issues.slice(0, 5),
  }));

  const siteSpecificSignals = {
    domain,
    industry: industry || "not specified",
    highestSeverityFindings: findingsSummary.slice(0, 10),
    pagesReviewed: pageEvidence,
    detectedChannels: channelEvidence?.channels
      .filter(c => c.status !== "missing")
      .map(c => `${c.channel}: ${c.status}/${c.quality}`) || [],
    missingOrWeakChannels: channelEvidence?.channels
      .filter(c => c.status === "missing" || c.quality === "poor" || c.quality === "needs-work")
      .map(c => `${c.channel}: ${c.details}`) || [],
    competitorGaps: competitorEvidence?.primaryGaps || [],
    competitorQuickWins: competitorEvidence?.quickWins || [],
  };
  
  return `
You are an elite Chief Marketing Officer and growth strategist creating a board-ready marketing audit.
Your output should feel like a sharp CMO memo: commercially useful, specific to this website, and written with taste.
Do not sound like a generic SEO checklist generator.

${ragContext}

───────────────────────────────────────────
AUDIT DATA FOR: ${domain}
Industry: ${industry || "Not specified"}
───────────────────────────────────────────

## FINDINGS SUMMARY:
- Critical Errors: ${errors.length}
- Warnings: ${warnings.length}  
- Opportunities: ${opportunities.length}

## DETAILED FINDINGS:
${JSON.stringify(findingsSummary, null, 2)}

## PAGE SPEED METRICS:
${pageSpeedMetrics ? JSON.stringify(pageSpeedMetrics, null, 2) : "Not available"}

## GEO/AI VISIBILITY:
${geoVisibility ? JSON.stringify(geoVisibility, null, 2) : "Not available"}

## LINK GRAPH:
${linkGraph ? JSON.stringify(linkGraph, null, 2) : "Not available"}

## COMPETITOR INTELLIGENCE:
${competitorEvidence ? JSON.stringify(competitorEvidence, null, 2) : "Not available"}

## SOCIAL / CHANNEL INTELLIGENCE:
${channelEvidence ? JSON.stringify(channelEvidence, null, 2) : "Not available"}

## SOCIAL PROFILE API EVIDENCE:
${JSON.stringify(socialProfileEvidence, null, 2)}

## COMPUTED SOCIAL ANALYTICS FEATURES:
${computedSocialAnalysis ? JSON.stringify(computedSocialAnalysis, null, 2) : "Not available"}

## CRAWLED PAGES (sample):
${crawledPages ? JSON.stringify(crawledPages.slice(0, 10), null, 2) : "Not available"}

## SITE-SPECIFIC MARKETING BRIEF:
${JSON.stringify(siteSpecificSignals, null, 2)}

───────────────────────────────────────────
INSTRUCTIONS:
───────────────────────────────────────────

Generate a comprehensive CMO-quality report with the following structure.
Be SPECIFIC - include actual URLs, actual numbers, actual steps.
Do NOT give generic advice. Every recommendation must be directly tied to findings.
Do NOT invent competitor, social, keyword, backlink, or traffic metrics. If a metric is missing, label it "not available" and recommend the API/instrumentation needed.
Use competitor and channel evidence wherever available. If competitor data is mock or inferred, clearly phrase it as an estimate.
Write recommendations as campaign and growth moves, not just fixes. For example, turn "missing blog" into a concrete content series, distribution channel, lead magnet, and KPI.
Avoid repeated generic phrases such as "improve search visibility", "better user experience", "optimize content", "leverage social media", unless followed by a specific page, channel, message angle, or measurable outcome.
Use the SITE-SPECIFIC MARKETING BRIEF as the primary source of truth. Every major section must mention at least one concrete signal from it: a URL, page title, missing channel, competitor gap, score, or finding title.

Social analysis operating rules:
- You are a senior CMO, growth strategist, and social media analyst.
- Analyze ONLY the provided social data.
- Never make assumptions or invent metrics.
- Never calculate or modify the social maturity score. Copy the computed social_strength and breakdown from COMPUTED SOCIAL ANALYTICS FEATURES.
- Every social insight must reference evidence: platform, follower count, engagement rate, posting frequency, sampled post count, theme percentage, or brand alignment issue.
- If evidence is insufficient, explicitly state "Insufficient data available."
- Focus on engagement quality, content effectiveness, posting consistency, audience interaction, brand positioning alignment, and growth opportunities.
- Avoid generic marketing advice. Use numbers wherever possible.

Use the knowledge base context above to enhance your recommendations with:
- Industry best practices
- Step-by-step implementation guides
- Proven fix templates
- Relevant benchmarks

Style target:
- Strategic but plain-spoken.
- Specific enough that a founder or marketer can act without asking "what exactly do I do?"
- Include sharp marketing angles, content themes, channel priorities, and conversion ideas.
- No hype, no filler, no copy-pasted phrases across reports.

Return ONLY valid JSON matching this exact structure:

{
  "executiveSummary": {
    "headline": "One powerful sentence summarizing the site's SEO state",
    "currentState": "2-3 sentences on current performance with specific metrics",
    "topOpportunity": "The single biggest opportunity with expected impact",
    "expectedImpact": "Quantified expected improvement (e.g., '40% increase in organic traffic')",
    "timeToValue": "Realistic timeline to see results"
  },
  
  "overallScore": 0-100,
  
  "categoryScores": {
    "technicalSEO": 0-100,
    "onPageSEO": 0-100,
    "performance": 0-100,
    "geoVisibility": 0-100,
    "contentQuality": 0-100,
    "linkHealth": 0-100
  },
  
  "immediateActions": [
    {
      "id": "action_1",
      "title": "Fix Critical Title Tags",
      "description": "Detailed description of what to fix and why",
      "priority": "CRITICAL|HIGH|MEDIUM|LOW",
      "effort": "QUICK_WIN|MODERATE|SIGNIFICANT|MAJOR_PROJECT",
      "impact": "Expected impact with metrics",
      "category": "technical_seo|on_page|performance|content|links",
      "affectedPages": ["https://example.com/page1", "https://example.com/page2"],
      "implementationSteps": [
        "Step 1: specific action",
        "Step 2: specific action"
      ],
      "toolsNeeded": ["Google Search Console", "Screaming Frog"],
      "expectedOutcome": "What will improve after implementation",
      "deadline": "This week"
    }
  ],
  
  "weeklyBacklog": [...],
  
  "strategicInitiatives": [...],
  
  "technicalSEO": {
    "score": 0-100,
    "summary": "Assessment of technical SEO health",
    "strengths": ["What's working well"],
    "weaknesses": ["What needs improvement"],
    "recommendations": ["Specific recommendations"]
  },
  
  "contentStrategy": {
    "currentAssessment": "Assessment of current content",
    "contentGaps": ["Topics/pages missing"],
    "topicOpportunities": ["Content to create"],
    "repurposingIdeas": [
      {
        "existingContent": "URL or description of existing content",
        "newFormats": ["Blog post → Video", "Guide → Infographic"],
        "targetPlatforms": ["LinkedIn", "YouTube"],
        "estimatedReach": "Potential reach/engagement"
      }
    ]
  },
  
  "geoStrategy": {
    "currentVisibility": "How visible in AI search engines",
    "aiReadinessScore": 0-100,
    "recommendations": ["How to improve AI visibility"],
    "contentEnhancements": ["Content changes for AI"],
    "structuredDataNeeds": ["Schema.org markup needed"]
  },
  
  "competitorInsights": {
    "identifiedCompetitors": ["Based on industry/content"],
    "competitorStrengths": ["What competitors do well"],
    "gapsToExploit": ["Where you can beat them"],
    "differentiationOpportunities": ["How to stand out"]
  },
  
  "socialStrategy": {
    "overallAssessment": "Current social integration state with evidence",
    "executiveSummary": [
      "3-5 evidence-backed findings. Each item cites a metric, platform, theme percentage, or alignment finding."
    ],
    "strengths": [
      "Evidence-backed strength citing actual metrics"
    ],
    "weaknesses": [
      "Evidence-backed weakness citing actual metrics"
    ],
    "contentStrategyAnalysis": [
      "Theme and content format analysis using COMPUTED SOCIAL ANALYTICS FEATURES"
    ],
    "audienceEngagementAnalysis": [
      "Engagement quality and audience interaction analysis using computed metrics"
    ],
    "brandConsistencyAnalysis": [
      "Website positioning vs social positioning comparison"
    ],
    "growthOpportunities": [
      "Prioritized, metric-backed opportunities"
    ],
    "ninetyDayActionPlan": [
      "Specific 90-day actions tied to the observed data"
    ],
    "overallSocialMaturityScore": 0-100,
    "scoreBreakdown": {
      "engagement": 0-100,
      "consistency": 0-100,
      "content_quality": 0-100,
      "audience_interaction": 0-100,
      "growth_potential": 0-100
    },
    "platformRecommendations": [
      {
        "platform": "LinkedIn",
        "priority": "HIGH|MEDIUM|LOW",
        "currentState": "Assessment of current presence",
        "recommendations": ["Specific actions"],
        "contentTypes": ["Article", "Carousel", "Video"]
      }
    ],
    "contentCalendarIdeas": ["Content themes/ideas"],
    "integrationOpportunities": ["How to connect SEO + Social"]
  },
  
  "contentGrowthPlan": {
    "thirtyDays": {
      "focus": "Main focus area",
      "deliverables": ["Specific deliverables"],
      "expectedOutcomes": ["What to achieve"],
      "kpis": ["Metrics to track"]
    },
    "sixtyDays": {...},
    "ninetyDays": {...}
  }
}

CRITICAL REQUIREMENTS:
1. Every actionItem MUST have specific affectedPages URLs from the audit
2. implementationSteps MUST be detailed, not generic
3. Include at least 3 immediate actions, 5 weekly backlog items
4. competitorInsights should use competitorEvidence when available; otherwise say competitor data is not available and recommend how to collect it
5. GEO strategy is REQUIRED if geoVisibility data exists
6. All scores must be justified by actual findings
7. Use the RAG context to enhance recommendations with best practices
8. competitorInsights must cite actual competitorEvidence numbers when available
9. socialStrategy must reference discovered social/channel evidence, not generic platform advice
10. Do not output a "brutalVerdict" field; use executiveSummary and the structured sections
11. contentStrategy.topicOpportunities must contain concrete topic angles tailored to this domain, not generic SEO topics
12. socialStrategy.contentCalendarIdeas must include post concepts derived from current pages/findings/channels
13. socialStrategy.platformRecommendations must cite the exact platform state from SOCIAL PROFILE API EVIDENCE: profile URL, follower count, recent post sample count, engagement rate, or "not available"
14. If API dataSources are "profile-discovery-only", say metrics were unavailable and recommend connecting SOCIALDATA_API_KEY for X/Twitter and APIFY_API_TOKEN for multi-platform profile metrics
15. Do not repeat the same socialStrategy across audits; tailor the content ideas to the crawled page titles, detected platforms, and available profile metrics
16. competitorInsights must treat Gemini-assisted or web-discovered competitors as candidates, not verified market leaders, unless metricsAvailable is true
17. competitorInsights.identifiedCompetitors must only include domains present in COMPETITOR INTELLIGENCE; do not add new competitor domains in the report
18. competitorInsights strengths/gaps must be based on visible evidence, page context, and available competitor candidate domains; do not invent traffic, ranking, backlink, or revenue claims
19. socialStrategy.overallSocialMaturityScore MUST equal COMPUTED SOCIAL ANALYTICS FEATURES.social_strength exactly when available
20. socialStrategy.scoreBreakdown MUST equal COMPUTED SOCIAL ANALYTICS FEATURES.breakdown exactly when available
21. socialStrategy strengths, weaknesses, contentStrategyAnalysis, audienceEngagementAnalysis, brandConsistencyAnalysis, and growthOpportunities must each cite concrete evidence or say "Insufficient data available."
22. The final social recommendations must be brand-specific by referencing website_positioning, social_positioning, platform_health, theme_distribution, or brand_alignment

Return ONLY the JSON object, no markdown, no explanation.
`;
}

// ─────────────────────────────────────────
// FALLBACK REPORT
// ─────────────────────────────────────────

function generateFallbackReport(auditData: AuditData): CMOReport {
  const { domain, findings } = auditData;
  
  const errors = findings.filter(f => f.severity === "ERROR");
  const warnings = findings.filter(f => f.severity === "WARNING");
  
  const score = Math.max(0, 100 - (errors.length * 10) - (warnings.length * 3));
  
  return {
    executiveSummary: {
      headline: `${domain} requires attention on ${errors.length} critical issues`,
      currentState: `Found ${errors.length} errors and ${warnings.length} warnings requiring attention.`,
      topOpportunity: errors[0]?.message || errors[0]?.description || errors[0]?.title || "Address technical SEO issues",
      expectedImpact: "Improved search visibility after fixes",
      timeToValue: "2-4 weeks after implementation",
    },
    
    overallScore: score,
    
    categoryScores: {
      technicalSEO: score,
      onPageSEO: score,
      performance: auditData.pageSpeedMetrics?.performance || 50,
      geoVisibility: auditData.geoVisibility?.overallScore || 0,
      contentQuality: 50,
      linkHealth: 50,
    },
    
    immediateActions: errors.slice(0, 3).map((f, i) => ({
      id: `action_${i + 1}`,
      title: `Fix: ${f.type.replace(/_/g, ' ')}`,
      description: f.message || f.description || f.title || f.type,
      priority: "CRITICAL" as const,
      effort: "MODERATE" as const,
      impact: "High impact on SEO",
      category: "technical_seo",
      affectedPages: f.affectedPages || f.affectedUrls || [],
      implementationSteps: ["Review the issue", "Implement the fix", "Verify the change"],
      toolsNeeded: ["Google Search Console"],
      expectedOutcome: "Issue resolved",
    })),
    
    weeklyBacklog: warnings.slice(0, 5).map((f, i) => ({
      id: `backlog_${i + 1}`,
      title: `Address: ${f.type.replace(/_/g, ' ')}`,
      description: f.message || f.description || f.title || f.type,
      priority: "MEDIUM" as const,
      effort: "MODERATE" as const,
      impact: "Medium impact on SEO",
      category: "on_page",
      affectedPages: f.affectedPages || f.affectedUrls || [],
      implementationSteps: ["Review", "Fix", "Verify"],
      toolsNeeded: [],
      expectedOutcome: "Issue resolved",
    })),
    
    strategicInitiatives: [],
    
    technicalSEO: {
      score,
      summary: "Technical SEO review completed",
      strengths: [],
      weaknesses: errors.map(e => e.message || e.description || e.title || e.type),
      recommendations: [],
    },
    
    contentStrategy: {
      currentAssessment: "Content needs review",
      contentGaps: [],
      topicOpportunities: [],
      repurposingIdeas: [],
    },
    
    geoStrategy: {
      currentVisibility: "Unknown",
      aiReadinessScore: 0,
      recommendations: [],
      contentEnhancements: [],
      structuredDataNeeds: [],
    },
    
    competitorInsights: {
      identifiedCompetitors: [],
      competitorStrengths: [],
      gapsToExploit: [],
      differentiationOpportunities: [],
    },
    
    socialStrategy: {
      overallAssessment: "Needs review",
      platformRecommendations: [],
      contentCalendarIdeas: [],
      integrationOpportunities: [],
    },
    
    contentGrowthPlan: {
      thirtyDays: {
        focus: "Fix critical errors",
        deliverables: ["Fix all critical issues"],
        expectedOutcomes: ["Improved SEO health"],
        kpis: ["Error count reduction"],
      },
      sixtyDays: {
        focus: "Address warnings",
        deliverables: [],
        expectedOutcomes: [],
        kpis: [],
      },
      ninetyDays: {
        focus: "Optimize for growth",
        deliverables: [],
        expectedOutcomes: [],
        kpis: [],
      },
    },
    
    citations: [],
    generatedAt: new Date().toISOString(),
    ragContextUsed: false,
    tokensUsed: 0,
  };
}

// ─────────────────────────────────────────
// EXPORTS
// ─────────────────────────────────────────

export {
  buildCMOPrompt,
  generateFallbackReport,
};
