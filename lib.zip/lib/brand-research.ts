/**
 * Lightweight public web research helpers.
 *
 * These helpers intentionally avoid paid APIs so audits can still enrich brand,
 * competitor, and social context in development. If search engines block the
 * request, callers fall back to crawl-only evidence instead of fabricating data.
 */

export interface WebSearchResult {
  title: string;
  url: string;
  snippet: string;
  domain: string;
}

export interface SocialProfile {
  platform: string;
  url: string;
  source: "website" | "search" | "direct";
  confidence: number;
  username?: string;
  metrics?: SocialProfileMetrics;
}

export interface SocialPost {
  id?: string;
  url?: string;
  text?: string;
  type?: string;
  createdAt?: string;
  likes?: number;
  comments?: number;
  views?: number;
  shares?: number;
  replies?: number;
  hashtags?: string[];
}

export interface SocialProfileMetrics {
  followers?: number;
  following?: number;
  posts?: number;
  recentPosts?: number;
  avgEngagementRate?: number;
  avgLikes?: number;
  avgComments?: number;
  avgViews?: number;
  verified?: boolean;
  bio?: string;
  sampledPosts?: SocialPost[];
  dataSource: "socialdata" | "apify" | "socialdata, apify";
}

const EXCLUDED_COMPETITOR_DOMAINS = [
  "google.",
  "bing.",
  "duckduckgo.",
  "wikipedia.org",
  "linkedin.com",
  "facebook.com",
  "instagram.com",
  "twitter.com",
  "x.com",
  "youtube.com",
  "tiktok.com",
  "crunchbase.com",
  "similarweb.com",
  "semrush.com",
  "ahrefs.com",
  "g2.com",
  "capterra.com",
  "trustpilot.com",
  "glassdoor.com",
  "indeed.com",
  "bloomberg.com",
  "forbes.com",
  "reuters.com",
  "growthnavigate.com",
  "cbinsights.com",
  "businessmodelanalyst.com",
  "marketing91.com",
  "similarweb.com",
  "6sense.com",
  "owler.com",
  "companiesmarketcap.com",
  "statista.com",
  "investopedia.com",
  "gmpg.org",
  "w3.org",
  "schema.org",
  "wordpress.org",
  "wixstatic.com",
  "parastorage.com",
  "static.",
  "cdn.",
  "cloudfront.net",
  "googletagmanager.com",
  "google-analytics.com",
  "googleapis.com",
  "gstatic.com",
  "gravatar.com",
  "facebook.net",
];

export function getBrandNameFromDomain(domain: string): string {
  const clean = normalizeDomain(domain);
  const parts = clean.split(".");
  const label = parts.length > 2 && parts[0] === "www" ? parts[1] : parts[0];
  return label
    .replace(/[-_]+/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

export function normalizeDomain(input: string): string {
  try {
    const withProtocol = input.startsWith("http") ? input : `https://${input}`;
    return new URL(withProtocol).hostname.replace(/^www\./i, "").toLowerCase();
  } catch {
    return input.replace(/^https?:\/\//i, "").replace(/^www\./i, "").split("/")[0].toLowerCase();
  }
}

export async function searchWeb(query: string, maxResults = 10): Promise<WebSearchResult[]> {
  const url = `https://duckduckgo.com/html/?q=${encodeURIComponent(query)}`;

  try {
    const response = await fetchWithTimeout(url, {
      headers: {
        "User-Agent": "Mozilla/5.0",
        "Accept": "text/html,application/xhtml+xml",
      },
    }, 8000);

    if (!response.ok) return [];
    const html = await response.text();
    return parseDuckDuckGoResults(html).slice(0, maxResults);
  } catch {
    return [];
  }
}

export async function discoverCompetitorDomains(
  domain: string,
  contextTerms: string[] = []
): Promise<string[]> {
  const brand = getBrandNameFromDomain(domain);
  const ownDomain = normalizeDomain(domain);
  const queries = [
    `${brand} competitors alternatives`,
    `${brand} similar brands competitors`,
    `${brand} vs competitors`,
    contextTerms.length > 0 ? `${brand} ${contextTerms.slice(0, 4).join(" ")} competitors` : "",
  ].filter(Boolean);

  const counts = new Map<string, number>();
  const researchCorpus: string[] = [];
  const searchEvidence: string[] = [];

  for (const query of queries) {
    const results = await searchWeb(query, 8);
    for (const result of results) {
      searchEvidence.push(`${result.title} | ${result.url} | ${result.snippet}`);
      const candidate = normalizeDomain(result.domain);
      if (!isLikelyCompetitorDomain(candidate, ownDomain)) continue;
      counts.set(candidate, (counts.get(candidate) || 0) + 1);
    }

    const researchPages = results.filter((result) =>
      /competitors|alternatives|similar| vs /i.test(`${result.title} ${result.url}`)
    ).slice(0, 3);

    for (const page of researchPages) {
      const html = await fetchHtml(page.url);
      if (!html) continue;
      researchCorpus.push(stripHtml(html).slice(0, 6000));

      const linkedDomains = extractLinkedDomains(html)
        .filter((candidate) => candidate !== normalizeDomain(page.domain))
        .filter((candidate) => isLikelyCompetitorDomain(candidate, ownDomain));

      for (const linkedDomain of linkedDomains) {
        counts.set(linkedDomain, (counts.get(linkedDomain) || 0) + 2);
      }
    }
  }

  const modelExtractedDomains = await extractCompetitorDomainsWithGemini(
    brand,
    ownDomain,
    [...searchEvidence, ...researchCorpus].join("\n\n"),
    contextTerms
  );

  for (const modelDomain of modelExtractedDomains.slice(0, 8)) {
    if (isLikelyCompetitorDomain(modelDomain, ownDomain)) {
      counts.set(modelDomain, (counts.get(modelDomain) || 0) + 6);
    }
  }

  return Array.from(counts.entries())
    .sort((a, b) => b[1] - a[1])
    .map(([candidate]) => candidate)
    .slice(0, 5);
}

async function extractCompetitorDomainsWithGemini(
  brand: string,
  ownDomain: string,
  corpus: string,
  contextTerms: string[] = []
): Promise<string[]> {
  if (!process.env.OPENAI_API_KEY) return [];

  try {
    const { OpenAI } = await import("openai");
    const client = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });

    const context = contextTerms.slice(0, 20).join(", ") || "not available";
    const researchText = corpus.trim() || "No external search evidence was available.";

    const result = await client.chat.completions.create({
      model: process.env.OPENAI_RESEARCH_MODEL || process.env.OPENAI_CMO_MODEL || "gpt-4-turbo",
      messages: [
        {
          role: "user",
          content: `
Identify direct business competitors for the audited brand.

Rules:
- Return official company/brand website domains only, not article sites, social networks, analytics tools, CDNs, marketplaces, or news sites.
- Exclude the audited domain: ${ownDomain}
- Prefer competitors with evidence in the research text.
- If research text is weak, use the page/category context and your market knowledge, but only include brands that are plausibly direct alternatives to the audited company.
- Do not include agencies, directories, publishers, job boards, marketplaces, or generic SaaS tools unless they directly sell the same core offer.
- Return JSON only in this shape: {"domains":["example.com"]}

Brand: ${brand}
Audited domain: ${ownDomain}
Website/category context: ${context}
Research text:
${researchText.slice(0, 16000)}
`,
        },
      ],
      temperature: 0,
      response_format: { type: "json_object" },
    });

    const text = (result.choices[0]?.message?.content || "").trim();
    const parsed = JSON.parse(text.replace(/^```(?:json)?/i, "").replace(/```$/i, "").trim()) as { domains?: string[] };
    return (parsed.domains || []).map(normalizeDomain);
  } catch {
    return [];
  }
}

export async function discoverSocialProfiles(
  domain: string,
  existingUrls: string[] = []
): Promise<SocialProfile[]> {
  const brand = getBrandNameFromDomain(domain);
  const slug = brand.toLowerCase().replace(/[^a-z0-9]+/g, "");
  const ownDomain = normalizeDomain(domain);
  const profiles = new Map<string, SocialProfile>();

  for (const url of existingUrls) {
    const platform = platformFromUrl(url);
    const normalizedUrl = normalizeSocialUrl(url);
    if (!platform || !isLikelyProfileUrl(normalizedUrl)) continue;
    profiles.set(`${platform}:${normalizedUrl}`, {
      platform,
      url: normalizedUrl,
      source: "website",
      confidence: 90,
      username: extractUsernameFromSocialUrl(normalizedUrl),
    });
  }

  if (process.env.SOCIAL_PROFILE_GUESSING === "true") {
    const directCandidates = [
      { platform: "Instagram", url: `https://www.instagram.com/${slug}/` },
      { platform: "Facebook", url: `https://www.facebook.com/${slug}` },
      { platform: "LinkedIn", url: `https://www.linkedin.com/company/${slug}` },
      { platform: "YouTube", url: `https://www.youtube.com/@${slug}` },
      { platform: "TikTok", url: `https://www.tiktok.com/@${slug}` },
      { platform: "X/Twitter", url: `https://x.com/${slug}` },
    ];

    await Promise.all(directCandidates.map(async (candidate) => {
      if (await urlAppearsLive(candidate.url)) {
        profiles.set(`${candidate.platform}:${candidate.url}`, {
          ...candidate,
          source: "direct",
          confidence: 35,
          username: extractUsernameFromSocialUrl(candidate.url),
        });
      }
    }));
  }

  const searchResults = await searchWeb(`${brand} ${ownDomain} official social media Instagram LinkedIn YouTube TikTok`, 12);
  for (const result of searchResults) {
    const platform = platformFromUrl(result.url);
    if (!platform) continue;
    const url = normalizeSocialUrl(result.url);
    if (!isLikelyProfileUrl(url)) continue;
    if (!isSearchResultRelevantToBrand(result, brand, ownDomain, url)) continue;

    profiles.set(`${platform}:${url}`, {
      platform,
      url,
      source: "search",
      confidence: /official|verified/i.test(`${result.title} ${result.snippet}`) ? 85 : 65,
      username: extractUsernameFromSocialUrl(url),
    });
  }

  return Array.from(profiles.values()).sort((a, b) => b.confidence - a.confidence);
}

export function extractUsernameFromSocialUrl(url: string): string | undefined {
  try {
    const parsed = new URL(url);
    const parts = parsed.pathname.split("/").filter(Boolean);
    const host = parsed.hostname.toLowerCase();

    if (host.includes("linkedin.com")) {
      const companyIndex = parts.findIndex((part) => part === "company");
      return companyIndex >= 0 ? parts[companyIndex + 1] : parts[0];
    }

    if (host.includes("youtube.com")) {
      const handle = parts.find((part) => part.startsWith("@"));
      return handle || parts.at(-1);
    }

    return parts[0]?.replace(/^@/, "");
  } catch {
    return undefined;
  }
}

function parseDuckDuckGoResults(html: string): WebSearchResult[] {
  const results: WebSearchResult[] = [];
  const resultPattern = /<a\b(?=[^>]*class=["'][^"']*result__a[^"']*["'])([^>]*)>(.*?)<\/a>/gi;
  let match: RegExpExecArray | null;

  while ((match = resultPattern.exec(html)) !== null) {
    const hrefMatch = match[1].match(/href=["']([^"']+)["']/i);
    if (!hrefMatch) continue;
    const url = decodeDuckDuckGoUrl(stripHtml(hrefMatch[1]));
    const domain = normalizeDomain(url);
    if (!url || !domain) continue;

    results.push({
      title: stripHtml(match[2]),
      url,
      snippet: "",
      domain,
    });
  }

  return results;
}

async function fetchHtml(url: string): Promise<string | null> {
  try {
    const response = await fetchWithTimeout(url, {
      headers: {
        "User-Agent": "Mozilla/5.0",
        "Accept": "text/html,application/xhtml+xml",
      },
    }, 8000);

    if (!response.ok) return null;
    const contentType = response.headers.get("content-type") || "";
    if (!contentType.includes("text/html")) return null;
    return response.text();
  } catch {
    return null;
  }
}

function extractLinkedDomains(html: string): string[] {
  const domains = new Set<string>();
  const hrefPattern = /href=["']([^"']+)["']/gi;
  let match: RegExpExecArray | null;

  while ((match = hrefPattern.exec(html)) !== null) {
    const href = stripHtml(match[1]);
    if (!/^https?:\/\//i.test(href)) continue;
    const domain = normalizeDomain(href);
    if (domain) domains.add(domain);
  }

  return Array.from(domains);
}

function decodeDuckDuckGoUrl(rawUrl: string): string {
  try {
    const parsed = new URL(rawUrl.startsWith("http") ? rawUrl : `https://duckduckgo.com${rawUrl}`);
    const uddg = parsed.searchParams.get("uddg");
    return uddg ? decodeURIComponent(uddg) : rawUrl;
  } catch {
    return rawUrl;
  }
}

function stripHtml(value: string): string {
  return value
    .replace(/<[^>]+>/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, "\"")
    .replace(/&#x27;/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}

function isLikelyCompetitorDomain(candidate: string, ownDomain: string): boolean {
  if (!candidate || candidate === ownDomain || candidate.endsWith(`.${ownDomain}`)) return false;
  if (ownDomain.endsWith(`.${candidate}`)) return false;
  if (EXCLUDED_COMPETITOR_DOMAINS.some((excluded) => candidate.includes(excluded))) return false;
  return candidate.includes(".");
}

function platformFromUrl(url: string): string | null {
  const normalized = url.toLowerCase();
  if (normalized.includes("instagram.com")) return "Instagram";
  if (normalized.includes("linkedin.com")) return "LinkedIn";
  if (normalized.includes("facebook.com")) return "Facebook";
  if (normalized.includes("youtube.com") || normalized.includes("youtu.be")) return "YouTube";
  if (normalized.includes("tiktok.com")) return "TikTok";
  if (normalized.includes("twitter.com") || normalized.includes("x.com")) return "X/Twitter";
  return null;
}

function normalizeSocialUrl(url: string): string {
  try {
    const parsed = new URL(url);
    parsed.search = "";
    parsed.hash = "";
    return parsed.toString().replace(/\/$/, "");
  } catch {
    return url;
  }
}

function isLikelyProfileUrl(url: string): boolean {
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();
    const pathParts = parsed.pathname.split("/").filter(Boolean);
    const path = parsed.pathname.toLowerCase();

    if (/\/(share|intent|sharer|hashtag|explore|reel|p|posts?|status|watch|embed)\b/i.test(path)) {
      return false;
    }

    if (host.includes("linkedin.com")) {
      return pathParts[0] === "company" && Boolean(pathParts[1]);
    }

    if (host.includes("youtube.com")) {
      return pathParts[0]?.startsWith("@") || ["c", "channel", "user"].includes(pathParts[0]);
    }

    if (host.includes("youtu.be")) return false;
    if (host.includes("facebook.com")) return pathParts.length > 0 && !["share", "sharer", "groups", "events", "watch"].includes(pathParts[0]);
    if (host.includes("instagram.com")) return pathParts.length === 1;
    if (host.includes("tiktok.com")) return pathParts[0]?.startsWith("@") || false;
    if (host.includes("twitter.com") || host.includes("x.com")) return pathParts.length === 1;

    return true;
  } catch {
    return false;
  }
}

function isSearchResultRelevantToBrand(
  result: WebSearchResult,
  brand: string,
  ownDomain: string,
  socialUrl: string
): boolean {
  const text = `${result.title} ${result.snippet}`.toLowerCase();
  const brandTokens = brand.toLowerCase().split(/\s+/).filter((token) => token.length > 2);
  const domainLabel = ownDomain.split(".")[0];
  const username = extractUsernameFromSocialUrl(socialUrl)?.toLowerCase() || "";

  if (text.includes(ownDomain) || text.includes(domainLabel)) return true;
  if (username === domainLabel || username.includes(domainLabel)) return true;
  return brandTokens.some((token) => text.includes(token) || username.includes(token));
}

async function urlAppearsLive(url: string): Promise<boolean> {
  try {
    const response = await fetchWithTimeout(url, {
      method: "GET",
      redirect: "follow",
      headers: {
        "User-Agent": "Mozilla/5.0",
      },
    }, 5000);

    if (response.status === 404 || response.status === 410) return false;
    return response.status >= 200 && response.status < 500;
  } catch {
    return false;
  }
}

async function fetchWithTimeout(
  url: string,
  init: RequestInit,
  timeoutMs: number
): Promise<Response> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timeout);
  }
}
