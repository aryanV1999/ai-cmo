import type { CrawlResultV2 } from "./crawler-v2";
import type { SocialPost, SocialProfile } from "./brand-research";

export interface PlatformHealth {
  platform: string;
  url: string;
  username?: string;
  data_source: string;
  followers: number | "not available";
  following: number | "not available";
  posts: number | "not available";
  sampled_posts: number;
  avg_likes: number | "not available";
  avg_comments: number | "not available";
  avg_views: number | "not available";
  engagement_rate: number | "not available";
  posting_frequency_per_week: number | "not available";
  max_posting_gap_days: number | "not available";
  video_ratio: number;
  avg_caption_length: number;
  top_hashtags: string[];
  content_type_distribution: Record<string, number>;
  theme_distribution: Record<string, number>;
  score_breakdown: SocialScoreBreakdown;
  social_strength: number;
  evidence: string[];
  sampled_posts_preview: Array<{
    date?: string;
    type?: string;
    text?: string;
    likes?: number;
    comments?: number;
    views?: number;
    hashtags?: string[];
  }>;
}

export interface SocialScoreBreakdown {
  engagement: number;
  consistency: number;
  content_quality: number;
  audience_interaction: number;
  growth_potential: number;
}

export interface SocialAnalysisReport {
  social_strength: number;
  breakdown: SocialScoreBreakdown;
  platform_health: PlatformHealth[];
  theme_distribution: Record<string, number>;
  website_positioning: {
    summary: string;
    signals: string[];
    evidence: string[];
  };
  social_positioning: {
    summary: string;
    dominant_themes: string[];
    evidence: string[];
  };
  brand_alignment: {
    status: "aligned" | "partial-mismatch" | "mismatch" | "insufficient-data";
    score: number;
    issues: string[];
    evidence: string[];
  };
  aggregate_metrics: {
    total_followers: number;
    total_sampled_posts: number;
    avg_engagement_rate: number | "not available";
    avg_posting_frequency_per_week: number | "not available";
    platforms_with_metrics: number;
    platforms_with_posts: number;
  };
  evidence_summary: string[];
  weaknesses: string[];
  recommendations: string[];
  insufficient_data_reasons: string[];
}

type Theme =
  | "educational"
  | "product"
  | "ugc"
  | "testimonials"
  | "behind_the_scenes"
  | "trend_participation"
  | "influencer"
  | "discount_offer"
  | "community"
  | "other";

const THEME_KEYWORDS: Record<Theme, RegExp[]> = {
  educational: [
    /\b(how to|guide|tips?|learn|explainer|tutorial|webinar|mistakes?|strategy|framework|checklist)\b/i,
  ],
  product: [
    /\b(product|collection|launch|feature|demo|available|shop|buy|order|new arrival|drop)\b/i,
  ],
  ugc: [
    /\b(ugc|customer|community post|tagged us|repost|shared by|fan|user generated)\b/i,
  ],
  testimonials: [
    /\b(testimonial|review|case study|success story|customer story|results|before and after)\b/i,
  ],
  behind_the_scenes: [
    /\b(behind the scenes|bts|team|culture|office|factory|making of|day in the life|founder)\b/i,
  ],
  trend_participation: [
    /\b(trending|trend|challenge|meme|viral|sound on|pov|duet|stitch)\b/i,
  ],
  influencer: [
    /\b(influencer|creator|collab|collaboration|partner|ambassador|featuring|with @)\b/i,
  ],
  discount_offer: [
    /\b(discount|sale|offer|deal|coupon|promo|clearance|% off|free shipping|limited time)\b/i,
  ],
  community: [
    /\b(community|join us|event|meetup|members|thank you|celebrate|conversation)\b/i,
  ],
  other: [],
};

const WEBSITE_POSITIONING_SIGNALS: Array<{ signal: string; pattern: RegExp }> = [
  { signal: "premium", pattern: /\b(premium|luxury|high-end|exclusive|crafted|bespoke)\b/i },
  { signal: "performance", pattern: /\b(performance|speed|faster|scale|reliable|powerful|efficient)\b/i },
  { signal: "value", pattern: /\b(affordable|budget|low cost|save|discount|deal|value)\b/i },
  { signal: "enterprise", pattern: /\b(enterprise|teams|platform|workflow|security|compliance|automation)\b/i },
  { signal: "education", pattern: /\b(course|learn|training|academy|guide|knowledge)\b/i },
  { signal: "community", pattern: /\b(community|members|creators|network|together)\b/i },
  { signal: "innovation", pattern: /\b(ai|innovation|future|technology|modern|intelligent)\b/i },
  { signal: "trust", pattern: /\b(trusted|secure|certified|proven|customers|case studies)\b/i },
];

export function buildSocialAnalysis(
  profiles: SocialProfile[],
  crawlData: CrawlResultV2
): SocialAnalysisReport {
  const platformHealth = profiles.map(analyzePlatform);
  const breakdown = weightedBreakdown(platformHealth);
  const themeDistribution = aggregateThemeDistribution(platformHealth);
  const websitePositioning = extractWebsitePositioning(crawlData);
  const socialPositioning = extractSocialPositioning(themeDistribution, platformHealth);
  const brandAlignment = compareWebsiteAndSocialPositioning(
    websitePositioning,
    socialPositioning,
    themeDistribution
  );

  const socialStrength = calculateWeightedSocialStrength(breakdown);
  const aggregateMetrics = aggregateMetricsFor(platformHealth);
  const insufficientDataReasons = buildDataGaps(profiles, platformHealth);
  const evidenceSummary = buildEvidenceSummary(platformHealth, aggregateMetrics, brandAlignment);
  const weaknesses = buildWeaknesses(breakdown, aggregateMetrics, brandAlignment, themeDistribution);

  return {
    social_strength: socialStrength,
    breakdown,
    platform_health: platformHealth,
    theme_distribution: themeDistribution,
    website_positioning: websitePositioning,
    social_positioning: socialPositioning,
    brand_alignment: brandAlignment,
    aggregate_metrics: aggregateMetrics,
    evidence_summary: evidenceSummary,
    weaknesses,
    recommendations: buildRecommendations(breakdown, brandAlignment, themeDistribution, insufficientDataReasons),
    insufficient_data_reasons: insufficientDataReasons,
  };
}

function analyzePlatform(profile: SocialProfile): PlatformHealth {
  const metrics = profile.metrics;
  const posts = metrics?.sampledPosts || [];
  const followers = metrics?.followers;
  const avgLikes = metrics?.avgLikes ?? averageMetric(posts, "likes");
  const avgComments = metrics?.avgComments ?? averageMetric(posts, "comments");
  const avgViews = metrics?.avgViews ?? averageMetric(posts, "views");
  const engagementRate = normalizeEngagementRate(
    metrics?.avgEngagementRate ?? computeEngagementRate(followers, avgLikes, avgComments)
  );
  const postingStats = computePostingStats(posts);
  const contentTypes = computeContentTypes(posts);
  const themes = computeThemeDistribution(posts);
  const topHashtags = computeTopHashtags(posts);
  const avgCaptionLength = averageCaptionLength(posts);
  const videoRatio = computeVideoRatio(posts, contentTypes);

  const scoreBreakdown = {
    engagement: scoreEngagement(engagementRate),
    consistency: scoreConsistency(postingStats.frequencyPerWeek, postingStats.maxGapDays, posts.length),
    content_quality: scoreContentQuality(contentTypes, videoRatio, avgCaptionLength, themes, posts.length),
    audience_interaction: scoreAudienceInteraction(followers, avgComments, posts),
    growth_potential: 0,
  };
  scoreBreakdown.growth_potential = scoreGrowthPotential(scoreBreakdown, posts, followers);

  return {
    platform: displayPlatform(profile.platform),
    url: profile.url,
    username: profile.username,
    data_source: metrics?.dataSource || "profile-discovery-only",
    followers: numberOrUnavailable(followers),
    following: numberOrUnavailable(metrics?.following),
    posts: numberOrUnavailable(metrics?.posts),
    sampled_posts: posts.length,
    avg_likes: numberOrUnavailable(avgLikes),
    avg_comments: numberOrUnavailable(avgComments),
    avg_views: numberOrUnavailable(avgViews),
    engagement_rate: engagementRate === undefined ? "not available" : round(engagementRate * 100, 2),
    posting_frequency_per_week: postingStats.frequencyPerWeek === undefined
      ? "not available"
      : round(postingStats.frequencyPerWeek, 2),
    max_posting_gap_days: postingStats.maxGapDays === undefined ? "not available" : postingStats.maxGapDays,
    video_ratio: round(videoRatio, 2),
    avg_caption_length: Math.round(avgCaptionLength),
    top_hashtags: topHashtags,
    content_type_distribution: contentTypes,
    theme_distribution: themes,
    score_breakdown: scoreBreakdown,
    social_strength: calculateWeightedSocialStrength(scoreBreakdown),
    evidence: buildPlatformEvidence(profile, engagementRate, postingStats.frequencyPerWeek, themes, scoreBreakdown),
    sampled_posts_preview: posts.slice(0, 8).map(postPreview),
  };
}

function computeEngagementRate(
  followers: number | undefined,
  avgLikes: number | undefined,
  avgComments: number | undefined
): number | undefined {
  if (!followers || followers <= 0) return undefined;
  const interactions = (avgLikes || 0) + (avgComments || 0);
  return interactions > 0 ? interactions / followers : undefined;
}

function normalizeEngagementRate(value?: number): number | undefined {
  if (value === undefined || !Number.isFinite(value) || value < 0) return undefined;
  return value > 1 ? value / 100 : value;
}

function computePostingStats(posts: SocialPost[]): {
  frequencyPerWeek?: number;
  maxGapDays?: number;
} {
  const dates = posts
    .map((post) => parsePostDate(post.createdAt))
    .filter((date): date is Date => Boolean(date))
    .sort((a, b) => a.getTime() - b.getTime());

  if (dates.length < 2) return {};

  const rangeDays = Math.max(1, daysBetween(dates[0], dates[dates.length - 1]));
  const gaps = dates.slice(1).map((date, index) => daysBetween(dates[index], date));
  return {
    frequencyPerWeek: (dates.length / rangeDays) * 7,
    maxGapDays: Math.max(...gaps),
  };
}

function computeContentTypes(posts: SocialPost[]): Record<string, number> {
  const counts: Record<string, number> = {};
  for (const post of posts) {
    const type = normalizeContentType(post.type, post);
    counts[type] = (counts[type] || 0) + 1;
  }
  return percentDistribution(counts);
}

function computeVideoRatio(posts: SocialPost[], contentTypes: Record<string, number>): number {
  if (posts.length === 0) return 0;
  return round(((contentTypes.video || 0) + (contentTypes.reel || 0) + (contentTypes.short || 0)) / 100, 2);
}

function normalizeContentType(type: string | undefined, post: SocialPost): string {
  const value = String(type || "").toLowerCase();
  if (/reel/.test(value)) return "reel";
  if (/short/.test(value)) return "short";
  if (/video|clip|tiktok/.test(value) || post.views !== undefined) return "video";
  if (/carousel|album|sidecar/.test(value)) return "carousel";
  if (/image|photo|picture/.test(value)) return "image";
  return post.views !== undefined ? "video" : "unknown";
}

function computeThemeDistribution(posts: SocialPost[]): Record<string, number> {
  const counts: Record<string, number> = {};
  for (const post of posts) {
    const theme = classifyTheme(post.text || "", post.hashtags || []);
    counts[theme] = (counts[theme] || 0) + 1;
  }
  return percentDistribution(counts);
}

function classifyTheme(text: string, hashtags: string[]): Theme {
  const corpus = `${text} ${hashtags.map(tag => `#${tag}`).join(" ")}`;
  for (const theme of Object.keys(THEME_KEYWORDS) as Theme[]) {
    if (theme === "other") continue;
    if (THEME_KEYWORDS[theme].some(pattern => pattern.test(corpus))) return theme;
  }
  return "other";
}

function computeTopHashtags(posts: SocialPost[]): string[] {
  const counts = new Map<string, number>();
  for (const post of posts) {
    for (const hashtag of post.hashtags || []) {
      counts.set(hashtag, (counts.get(hashtag) || 0) + 1);
    }
  }
  return Array.from(counts.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([tag]) => tag);
}

function averageCaptionLength(posts: SocialPost[]): number {
  const lengths = posts
    .map(post => post.text?.trim().length || 0)
    .filter(length => length > 0);
  if (lengths.length === 0) return 0;
  return lengths.reduce((sum, value) => sum + value, 0) / lengths.length;
}

function scoreEngagement(engagementRate?: number): number {
  if (engagementRate === undefined) return 0;
  return clamp(Math.round((engagementRate / 0.05) * 100), 0, 100);
}

function scoreConsistency(
  frequencyPerWeek: number | undefined,
  maxGapDays: number | undefined,
  sampledPosts: number
): number {
  if (frequencyPerWeek === undefined) {
    return sampledPosts > 0 ? clamp(30 + sampledPosts * 3, 0, 55) : 0;
  }
  const frequencyScore = clamp(Math.round((frequencyPerWeek / 5) * 100), 0, 100);
  const gapPenalty = maxGapDays === undefined
    ? 0
    : maxGapDays >= 30
      ? 35
      : maxGapDays >= 14
        ? 20
        : maxGapDays >= 7
          ? 8
          : 0;
  return clamp(frequencyScore - gapPenalty, 0, 100);
}

function scoreContentQuality(
  contentTypes: Record<string, number>,
  videoRatio: number,
  avgCaptionLength: number,
  themes: Record<string, number>,
  sampledPosts: number
): number {
  if (sampledPosts === 0) return 0;
  const typeCount = Object.keys(contentTypes).filter(type => type !== "unknown" && contentTypes[type] > 0).length;
  const diversityScore = clamp(typeCount * 18, 0, 45);
  const videoScore = clamp(Math.round(videoRatio * 35), 0, 20);
  const captionScore = avgCaptionLength >= 60 && avgCaptionLength <= 240
    ? 20
    : avgCaptionLength > 0
      ? 10
      : 0;
  const themeCount = Object.keys(themes).filter(theme => theme !== "other" && themes[theme] > 0).length;
  const themeScore = clamp(themeCount * 5, 0, 15);
  return clamp(diversityScore + videoScore + captionScore + themeScore, 0, 100);
}

function scoreAudienceInteraction(
  followers: number | undefined,
  avgComments: number | undefined,
  posts: SocialPost[]
): number {
  const replyAvg = averageMetric(posts, "replies") || 0;
  if (!followers || followers <= 0) {
    return clamp(Math.round((avgComments || 0) * 2 + replyAvg * 4), 0, 60);
  }
  const commentRate = (avgComments || 0) / followers;
  const commentRateScore = clamp(Math.round((commentRate / 0.001) * 70), 0, 70);
  const replyScore = clamp(Math.round(replyAvg * 4), 0, 30);
  return clamp(commentRateScore + replyScore, 0, 100);
}

function scoreGrowthPotential(
  breakdown: Omit<SocialScoreBreakdown, "growth_potential">,
  posts: SocialPost[],
  followers?: number
): number {
  const performanceVariance = scorePerformanceVariance(posts);
  const smallAudienceBonus = followers !== undefined && followers > 0 && followers < 20000
    ? 8
    : 0;
  return clamp(Math.round(
    breakdown.engagement * 0.45 +
    breakdown.consistency * 0.2 +
    breakdown.content_quality * 0.15 +
    performanceVariance * 0.2 +
    smallAudienceBonus
  ), 0, 100);
}

function scorePerformanceVariance(posts: SocialPost[]): number {
  const values = posts
    .map(post => (post.likes || 0) + (post.comments || 0) + Math.round((post.views || 0) / 100))
    .filter(value => value > 0);
  if (values.length < 3) return 25;
  const avg = values.reduce((sum, value) => sum + value, 0) / values.length;
  const max = Math.max(...values);
  if (avg === 0) return 0;
  return clamp(Math.round((max / avg - 1) * 40), 0, 100);
}

function weightedBreakdown(platformHealth: PlatformHealth[]): SocialScoreBreakdown {
  if (platformHealth.length === 0) {
    return {
      engagement: 0,
      consistency: 0,
      content_quality: 0,
      audience_interaction: 0,
      growth_potential: 0,
    };
  }

  return {
    engagement: weightedScore(platformHealth, "engagement"),
    consistency: weightedScore(platformHealth, "consistency"),
    content_quality: weightedScore(platformHealth, "content_quality"),
    audience_interaction: weightedScore(platformHealth, "audience_interaction"),
    growth_potential: weightedScore(platformHealth, "growth_potential"),
  };
}

function weightedScore(platformHealth: PlatformHealth[], key: keyof SocialScoreBreakdown): number {
  const totalWeight = platformHealth.reduce((sum, platform) => sum + platformWeight(platform), 0);
  if (totalWeight === 0) return 0;
  return Math.round(
    platformHealth.reduce((sum, platform) => (
      sum + platform.score_breakdown[key] * platformWeight(platform)
    ), 0) / totalWeight
  );
}

export function calculateWeightedSocialStrength(breakdown: SocialScoreBreakdown): number {
  return Math.round(
    breakdown.engagement * 0.3 +
    breakdown.consistency * 0.2 +
    breakdown.content_quality * 0.2 +
    breakdown.audience_interaction * 0.15 +
    breakdown.growth_potential * 0.15
  );
}

function platformWeight(platform: PlatformHealth): number {
  const followers = typeof platform.followers === "number" ? platform.followers : 0;
  return Math.max(1, Math.log10(followers + 10));
}

function aggregateThemeDistribution(platformHealth: PlatformHealth[]): Record<string, number> {
  const weightedCounts: Record<string, number> = {};
  let totalPosts = 0;

  for (const platform of platformHealth) {
    totalPosts += platform.sampled_posts;
    for (const [theme, percent] of Object.entries(platform.theme_distribution)) {
      weightedCounts[theme] = (weightedCounts[theme] || 0) + (percent / 100) * platform.sampled_posts;
    }
  }

  if (totalPosts === 0) return {};
  return Object.fromEntries(
    Object.entries(weightedCounts)
      .map(([theme, count]) => [theme, Math.round((count / totalPosts) * 100)])
      .sort((a, b) => Number(b[1]) - Number(a[1]))
  );
}

function aggregateMetricsFor(platformHealth: PlatformHealth[]): SocialAnalysisReport["aggregate_metrics"] {
  const totalFollowers = platformHealth.reduce((sum, platform) => (
    sum + (typeof platform.followers === "number" ? platform.followers : 0)
  ), 0);
  const engagementRates = platformHealth
    .map(platform => typeof platform.engagement_rate === "number" ? platform.engagement_rate : undefined)
    .filter((value): value is number => value !== undefined);
  const postingFrequencies = platformHealth
    .map(platform => typeof platform.posting_frequency_per_week === "number" ? platform.posting_frequency_per_week : undefined)
    .filter((value): value is number => value !== undefined);

  return {
    total_followers: totalFollowers,
    total_sampled_posts: platformHealth.reduce((sum, platform) => sum + platform.sampled_posts, 0),
    avg_engagement_rate: engagementRates.length > 0
      ? round(engagementRates.reduce((sum, value) => sum + value, 0) / engagementRates.length, 2)
      : "not available",
    avg_posting_frequency_per_week: postingFrequencies.length > 0
      ? round(postingFrequencies.reduce((sum, value) => sum + value, 0) / postingFrequencies.length, 2)
      : "not available",
    platforms_with_metrics: platformHealth.filter(platform => platform.data_source !== "profile-discovery-only").length,
    platforms_with_posts: platformHealth.filter(platform => platform.sampled_posts > 0).length,
  };
}

function extractWebsitePositioning(crawlData: CrawlResultV2): SocialAnalysisReport["website_positioning"] {
  const evidence = crawlData.pages.slice(0, 12).flatMap(page => [
    page.title || "",
    page.metaDescription || "",
    ...page.h1Tags.slice(0, 2),
    ...page.h2Tags.slice(0, 3),
  ]).filter(Boolean);
  const corpus = evidence.join(" ");
  const signals = WEBSITE_POSITIONING_SIGNALS
    .filter(item => item.pattern.test(corpus))
    .map(item => item.signal);

  return {
    summary: signals.length > 0
      ? `${crawlData.domain} website positioning emphasizes ${signals.slice(0, 4).join(", ")}.`
      : "Website positioning could not be confidently classified from crawled titles and headings.",
    signals,
    evidence: evidence.slice(0, 8),
  };
}

function extractSocialPositioning(
  themeDistribution: Record<string, number>,
  platformHealth: PlatformHealth[]
): SocialAnalysisReport["social_positioning"] {
  const dominantThemes = Object.entries(themeDistribution)
    .filter(([, percent]) => percent >= 10)
    .sort((a, b) => b[1] - a[1])
    .map(([theme, percent]) => `${theme}: ${percent}%`);
  const evidence = platformHealth
    .flatMap(platform => platform.sampled_posts_preview.map(post => post.text || ""))
    .filter(Boolean)
    .slice(0, 8);

  return {
    summary: dominantThemes.length > 0
      ? `Social content is dominated by ${dominantThemes.slice(0, 3).join(", ")}.`
      : "Social content themes could not be classified because no recent post text was available.",
    dominant_themes: dominantThemes,
    evidence,
  };
}

function compareWebsiteAndSocialPositioning(
  website: SocialAnalysisReport["website_positioning"],
  social: SocialAnalysisReport["social_positioning"],
  themes: Record<string, number>
): SocialAnalysisReport["brand_alignment"] {
  if (website.signals.length === 0 || Object.keys(themes).length === 0) {
    return {
      status: "insufficient-data",
      score: 0,
      issues: ["Insufficient website or recent social post evidence to compare positioning."],
      evidence: [...website.evidence.slice(0, 3), ...social.evidence.slice(0, 3)],
    };
  }

  const issues: string[] = [];
  if ((website.signals.includes("premium") || website.signals.includes("performance")) && (themes.discount_offer || 0) >= 35) {
    issues.push(`Website positioning emphasizes ${website.signals.join(", ")} while ${themes.discount_offer}% of social posts are discount/offer-led.`);
  }
  if (website.signals.includes("enterprise") && (themes.product || 0) > 50 && (themes.educational || 0) < 15) {
    issues.push(`Website has enterprise signals, but social content is ${themes.product}% product-led and only ${themes.educational || 0}% educational.`);
  }
  if (website.signals.includes("community") && (themes.community || 0) < 10 && (themes.ugc || 0) < 10) {
    issues.push("Website suggests community positioning, but recent social posts show limited community or UGC themes.");
  }

  const score = issues.length === 0 ? 85 : issues.length === 1 ? 55 : 35;
  return {
    status: issues.length === 0 ? "aligned" : issues.length === 1 ? "partial-mismatch" : "mismatch",
    score,
    issues,
    evidence: [...website.evidence.slice(0, 3), ...social.evidence.slice(0, 3)],
  };
}

function buildEvidenceSummary(
  platformHealth: PlatformHealth[],
  aggregate: SocialAnalysisReport["aggregate_metrics"],
  alignment: SocialAnalysisReport["brand_alignment"]
): string[] {
  const strongest = [...platformHealth].sort((a, b) => b.social_strength - a.social_strength)[0];
  const weakest = [...platformHealth].sort((a, b) => a.social_strength - b.social_strength)[0];
  const items: string[] = [];

  if (strongest) {
    items.push(`${strongest.platform} is the strongest measured channel with social strength ${strongest.social_strength}/100 and engagement ${formatMetric(strongest.engagement_rate, "%")}.`);
  }
  if (weakest && weakest !== strongest) {
    items.push(`${weakest.platform} is the weakest measured channel with social strength ${weakest.social_strength}/100.`);
  }
  items.push(`${aggregate.platforms_with_metrics} platforms have API/scraped metrics and ${aggregate.platforms_with_posts} platforms include recent post samples.`);
  if (aggregate.total_followers > 0) {
    items.push(`Measured social audience totals ${aggregate.total_followers.toLocaleString("en")} followers/subscribers.`);
  }
  if (alignment.status !== "aligned") {
    items.push(...alignment.issues);
  }

  return items;
}

function buildWeaknesses(
  breakdown: SocialScoreBreakdown,
  aggregate: SocialAnalysisReport["aggregate_metrics"],
  alignment: SocialAnalysisReport["brand_alignment"],
  themes: Record<string, number>
): string[] {
  const weaknesses: string[] = [];
  if (breakdown.engagement < 45) weaknesses.push(`Engagement score is ${breakdown.engagement}/100, indicating low or unavailable interaction relative to audience size.`);
  if (breakdown.consistency < 45) weaknesses.push(`Consistency score is ${breakdown.consistency}/100, indicating posting gaps or missing timestamp data.`);
  if (breakdown.content_quality < 45) weaknesses.push(`Content quality/diversity score is ${breakdown.content_quality}/100 across sampled posts.`);
  if (breakdown.audience_interaction < 45) weaknesses.push(`Audience interaction score is ${breakdown.audience_interaction}/100 based on comment and reply signals.`);
  if (aggregate.total_sampled_posts === 0) weaknesses.push("No recent post samples were available, so content theme and consistency analysis is limited.");
  if ((themes.other || 0) >= 60) weaknesses.push(`${themes.other}% of sampled posts could not be assigned a specific strategy theme.`);
  weaknesses.push(...alignment.issues);
  return Array.from(new Set(weaknesses));
}

function buildRecommendations(
  breakdown: SocialScoreBreakdown,
  alignment: SocialAnalysisReport["brand_alignment"],
  themes: Record<string, number>,
  dataGaps: string[]
): string[] {
  const recommendations: string[] = [];
  if (breakdown.engagement < 55) recommendations.push("Prioritize formats and topics with measurable comment/like lift before increasing posting volume.");
  if (breakdown.consistency < 55) recommendations.push("Build a weekly publishing cadence and reduce long gaps between posts.");
  if (breakdown.content_quality < 55) recommendations.push("Increase format diversity across video, carousel/image, educational, testimonial, and community proof posts.");
  if (breakdown.audience_interaction < 55) recommendations.push("Add explicit comment prompts, reply workflows, and community-led post formats to lift interaction quality.");
  if ((themes.educational || 0) < 15) recommendations.push("Add more educational posts tied to website product/category messaging.");
  if ((themes.testimonials || 0) < 10 && (themes.ugc || 0) < 10) recommendations.push("Add customer proof through UGC, testimonials, or case-study snippets.");
  if (alignment.status === "partial-mismatch" || alignment.status === "mismatch") {
    recommendations.push("Realign the social content mix with the website positioning before scaling paid amplification.");
  }
  if (dataGaps.length > 0) recommendations.push("Resolve social data gaps before making channel budget decisions.");
  return Array.from(new Set(recommendations)).slice(0, 8);
}

function buildDataGaps(profiles: SocialProfile[], platformHealth: PlatformHealth[]): string[] {
  const gaps: string[] = [];
  if (profiles.length === 0) gaps.push("No social profiles were discovered.");
  for (const platform of platformHealth) {
    if (platform.data_source === "profile-discovery-only") {
      gaps.push(`${platform.platform}: API metrics unavailable.`);
    }
    if (platform.sampled_posts === 0) {
      gaps.push(`${platform.platform}: no recent post samples available from Apify/SocialData.`);
    }
    if (platform.engagement_rate === "not available") {
      gaps.push(`${platform.platform}: engagement rate unavailable because follower and interaction data are incomplete.`);
    }
  }
  return Array.from(new Set(gaps));
}

function buildPlatformEvidence(
  profile: SocialProfile,
  engagementRate: number | undefined,
  frequency: number | undefined,
  themes: Record<string, number>,
  breakdown: SocialScoreBreakdown
): string[] {
  const evidence: string[] = [];
  const metrics = profile.metrics;
  if (metrics?.followers !== undefined) evidence.push(`${displayPlatform(profile.platform)} followers: ${metrics.followers.toLocaleString("en")}.`);
  if (engagementRate !== undefined) evidence.push(`${displayPlatform(profile.platform)} engagement rate: ${round(engagementRate * 100, 2)}%.`);
  if (frequency !== undefined) evidence.push(`${displayPlatform(profile.platform)} posting frequency: ${round(frequency, 2)} posts/week.`);
  const dominantTheme = Object.entries(themes).sort((a, b) => b[1] - a[1])[0];
  if (dominantTheme) evidence.push(`${displayPlatform(profile.platform)} dominant theme: ${dominantTheme[0]} (${dominantTheme[1]}%).`);
  evidence.push(`${displayPlatform(profile.platform)} computed score breakdown: engagement ${breakdown.engagement}, consistency ${breakdown.consistency}, content quality ${breakdown.content_quality}, audience interaction ${breakdown.audience_interaction}, growth potential ${breakdown.growth_potential}.`);
  return evidence;
}

function averageMetric(posts: SocialPost[], key: "likes" | "comments" | "views" | "replies"): number | undefined {
  const values = posts
    .map(post => post[key])
    .filter((value): value is number => typeof value === "number" && Number.isFinite(value));
  if (values.length === 0) return undefined;
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function postPreview(post: SocialPost): PlatformHealth["sampled_posts_preview"][number] {
  return {
    date: post.createdAt,
    type: post.type,
    text: post.text?.slice(0, 220),
    likes: post.likes,
    comments: post.comments,
    views: post.views,
    hashtags: post.hashtags?.slice(0, 8),
  };
}

function percentDistribution(counts: Record<string, number>): Record<string, number> {
  const total = Object.values(counts).reduce((sum, count) => sum + count, 0);
  if (total === 0) return {};
  return Object.fromEntries(
    Object.entries(counts)
      .map(([key, count]) => [key, Math.round((count / total) * 100)])
      .sort((a, b) => Number(b[1]) - Number(a[1]))
  );
}

function parsePostDate(value?: string): Date | null {
  if (!value) return null;
  const date = new Date(value);
  return Number.isFinite(date.getTime()) ? date : null;
}

function daysBetween(start: Date, end: Date): number {
  return Math.max(0, Math.round((end.getTime() - start.getTime()) / 86400000));
}

function numberOrUnavailable(value: number | undefined): number | "not available" {
  return typeof value === "number" && Number.isFinite(value) ? Math.round(value) : "not available";
}

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

function round(value: number, decimals: number): number {
  const factor = 10 ** decimals;
  return Math.round(value * factor) / factor;
}

function displayPlatform(platform: string): string {
  return platform === "X/Twitter" ? "Twitter/X" : platform;
}

function formatMetric(value: number | "not available", suffix = ""): string {
  return typeof value === "number" ? `${value}${suffix}` : value;
}
